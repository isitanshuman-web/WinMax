; WinMax installer — build with Inno Setup 6.2 or newer (https://jrsoftware.org/isinfo.php)
; Run build.bat in the project root: it publishes the app and then compiles this script.

#define MyAppName "WinMax"
#define MyAppVersion "1.0.0"
#define MyAppExe "WinMax.exe"

[Setup]
AppId={{6F1B2C84-5D3A-4E7B-9C21-7A8E40D1B5F3}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=WinMax
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\{#MyAppExe}
SetupIconFile=..\Assets\winmax.ico
WizardStyle=modern
WizardImageFile=wizard_large.bmp
WizardSmallImageFile=wizard_small.bmp
OutputDir=..\dist
OutputBaseFilename=WinMax-Setup-{#MyAppVersion}
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Installs for the current user by default (no admin prompt). The user can still choose "all users".
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
; Windows 10 (1809+) and Windows 11
MinVersion=10.0.17763
; Setup warns if WinMax is running (mutex created by the app)
AppMutex=WinMax.SingleInstance.v1
CloseApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; Flags: unchecked
Name: "startup"; Description: "Start WinMax when I sign in to Windows (recommended)"; GroupDescription: "Startup:"

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "WinMax"; \
  ValueData: """{app}\{#MyAppExe}"" --startup"; Flags: uninsdeletevalue; Tasks: startup

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Launch WinMax now"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; Ask a running WinMax to exit so it can put the Windows taskbar back to normal first.
Filename: "{app}\{#MyAppExe}"; Parameters: "--quit"; Flags: runhidden waituntilterminated; RunOnceId: "QuitWinMax"

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    if MsgBox('Also delete your WinMax settings, widgets, notes and reminders?' + #13#10 +
              '(Choose No to keep them in case you reinstall.)', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
      DelTree(ExpandConstant('{userappdata}\WinMax'), True, True, True);
  end;
end;
