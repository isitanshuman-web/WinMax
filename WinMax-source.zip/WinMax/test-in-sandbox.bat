@echo off
setlocal
cd /d "%~dp0"
title WinMax - test in Windows Sandbox

if not exist "dist\WinMax-Setup-1.0.0.exe" (
  echo  Installer not found. Run build.bat first, then run this file again.
  pause
  exit /b 1
)

where WindowsSandbox.exe >nul 2>nul
if errorlevel 1 (
  echo  Windows Sandbox is not turned on.
  echo.
  echo  1. Press the Windows key, type "Turn Windows features on or off", open it
  echo  2. Tick "Windows Sandbox", click OK, restart the PC
  echo  3. Run this file again
  echo.
  echo  Needs Windows 10/11 Pro, Enterprise or Education. Home edition: use VirtualBox instead.
  pause
  exit /b 1
)

set "WSB=%TEMP%\WinMax-Test.wsb"
> "%WSB%" echo ^<Configuration^>
>> "%WSB%" echo   ^<VGpu^>Enable^</VGpu^>
>> "%WSB%" echo   ^<Networking^>Enable^</Networking^>
>> "%WSB%" echo   ^<MappedFolders^>
>> "%WSB%" echo     ^<MappedFolder^>
>> "%WSB%" echo       ^<HostFolder^>%CD%\dist^</HostFolder^>
>> "%WSB%" echo       ^<SandboxFolder^>C:\Users\WDAGUtilityAccount\Desktop\WinMax-Installer^</SandboxFolder^>
>> "%WSB%" echo       ^<ReadOnly^>true^</ReadOnly^>
>> "%WSB%" echo     ^</MappedFolder^>
>> "%WSB%" echo   ^</MappedFolders^>
>> "%WSB%" echo   ^<LogonCommand^>
>> "%WSB%" echo     ^<Command^>C:\Users\WDAGUtilityAccount\Desktop\WinMax-Installer\WinMax-Setup-1.0.0.exe^</Command^>
>> "%WSB%" echo   ^</LogonCommand^>
>> "%WSB%" echo ^</Configuration^>

echo  Starting a clean Windows desktop. The WinMax installer opens automatically.
echo  Everything inside is deleted when you close the Sandbox window.
start "" "%WSB%"
