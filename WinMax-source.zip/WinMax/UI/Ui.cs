using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using WinMax.Core;

namespace WinMax.UI;

/// <summary>Small control kit for the settings window (code-built, no XAML, no external theme).</summary>
public static class Ui
{
    public static SolidColorBrush B(Color c) => Theme.Solid(c);
    public static FontFamily Font = new("Segoe UI");
    public static FontFamily FontSemi = new("Segoe UI Semibold");

    public static TextBlock Txt(string s, double size, Color color, bool semi = false) => new()
    {
        Text = s, FontSize = size, Foreground = B(color), FontFamily = semi ? FontSemi : Font, TextWrapping = TextWrapping.Wrap
    };

    public static TextBlock H1(string s) => Txt(s, 26, Theme.UiText, true);
    public static TextBlock Sub(string s) => Txt(s, 13, Theme.UiSub);
    public static TextBlock H2(string s) => Txt(s, 15, Theme.UiText, true);

    public static Border Card(UIElement child, double pad = 18) => new()
    {
        Child = child, Padding = new Thickness(pad), Background = B(Theme.UiPanel), CornerRadius = new CornerRadius(14),
        BorderBrush = B(Theme.UiStroke), BorderThickness = new Thickness(1), Margin = new Thickness(0, 0, 0, 14)
    };

    public static StackPanel Col(params UIElement[] kids)
    {
        var p = new StackPanel();
        foreach (var k in kids) p.Children.Add(k);
        return p;
    }

    public static T Mar<T>(this T e, double l, double t, double r, double b) where T : FrameworkElement { e.Margin = new Thickness(l, t, r, b); return e; }

    /// <summary>Label + description on the left, control on the right.</summary>
    public static UIElement Row(string title, string? desc, UIElement control)
    {
        var g = new Grid { Margin = new Thickness(0, 6, 0, 6) };
        g.ColumnDefinitions.Add(new ColumnDefinition());
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var left = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 16, 0) };
        left.Children.Add(Txt(title, 14, Theme.UiText));
        if (!string.IsNullOrEmpty(desc)) left.Children.Add(Txt(desc, 12, Theme.UiSub).Mar(0, 2, 0, 0));
        g.Children.Add(left);
        if (control is FrameworkElement fe) fe.VerticalAlignment = VerticalAlignment.Center;
        Grid.SetColumn(control, 1);
        g.Children.Add(control);
        return g;
    }

    public static UIElement Switch(bool value, Action<bool> set)
    {
        bool on = value;
        var knob = new Border { Width = 18, Height = 18, CornerRadius = new CornerRadius(9), Background = Brushes.White, VerticalAlignment = VerticalAlignment.Center };
        var track = new Border { Width = 44, Height = 24, CornerRadius = new CornerRadius(12), Cursor = Cursors.Hand, Child = knob, Padding = new Thickness(3) };
        void Paint()
        {
            track.Background = on ? Theme.Accent : B(Theme.UiPanel2);
            knob.HorizontalAlignment = on ? HorizontalAlignment.Right : HorizontalAlignment.Left;
        }
        Paint();
        track.MouseLeftButtonUp += (_, _) => { on = !on; Paint(); set(on); };
        return track;
    }

    public static Border Btn(string text, Action click, bool primary = true, double minWidth = 0)
    {
        var tb = new TextBlock { Text = text, FontSize = 13, FontFamily = FontSemi, Foreground = primary ? Brushes.White : B(Theme.UiText), HorizontalAlignment = HorizontalAlignment.Center };
        var b = new Border
        {
            Child = tb, Padding = new Thickness(16, 8, 16, 8), CornerRadius = new CornerRadius(10), Cursor = Cursors.Hand, MinWidth = minWidth,
            Background = primary ? Theme.Accent : B(Theme.UiPanel2), HorizontalAlignment = HorizontalAlignment.Left
        };
        b.MouseEnter += (_, _) => b.Opacity = 0.85;
        b.MouseLeave += (_, _) => b.Opacity = 1;
        b.MouseLeftButtonUp += (_, _) => click();
        return b;
    }

    /// <summary>Single-choice pill selector (replaces ComboBox so it always matches the theme).</summary>
    public static UIElement Chips(string[] options, Func<string> get, Action<string> set, string[]? labels = null)
    {
        var wrap = new WrapPanel { HorizontalAlignment = HorizontalAlignment.Right };
        void Build()
        {
            wrap.Children.Clear();
            for (int i = 0; i < options.Length; i++)
            {
                string opt = options[i];
                bool sel = get() == opt;
                var chip = new Border
                {
                    Padding = new Thickness(14, 6, 14, 6), Margin = new Thickness(3), CornerRadius = new CornerRadius(16), Cursor = Cursors.Hand,
                    Background = sel ? Theme.Accent : B(Theme.UiPanel2),
                    Child = Txt(labels?[i] ?? opt, 12.5, sel ? Colors.White : Theme.UiText, sel)
                };
                chip.MouseLeftButtonUp += (_, _) => { set(opt); Build(); };
                wrap.Children.Add(chip);
            }
        }
        Build();
        return wrap;
    }

    public static UIElement SliderRow(string title, string? desc, double min, double max, double value, Action<double> set, string suffix = "", double step = 1)
    {
        var val = Txt("", 12, Theme.UiSub); val.Width = 52; val.TextAlignment = TextAlignment.Right; val.VerticalAlignment = VerticalAlignment.Center;
        var sl = new Slider { Minimum = min, Maximum = max, Value = value, Width = 180, VerticalAlignment = VerticalAlignment.Center, IsMoveToPointEnabled = true, TickFrequency = step, IsSnapToTickEnabled = step < 1 ? false : true };
        void Show() => val.Text = (step < 1 ? sl.Value.ToString("0.00") : Math.Round(sl.Value).ToString()) + suffix;
        Show();
        sl.ValueChanged += (_, _) => { Show(); set(sl.Value); };
        var sp = new StackPanel { Orientation = Orientation.Horizontal };
        sp.Children.Add(sl); sp.Children.Add(val);
        return Row(title, desc, sp);
    }

    public static UIElement Divider() => new Border { Height = 1, Background = B(Theme.UiStroke), Margin = new Thickness(0, 8, 0, 8) };

    public static UIElement HexBox(string value, Action<string> set)
    {
        var tb = new TextBox
        {
            Text = value, Width = 96, Padding = new Thickness(8, 5, 8, 5), FontFamily = new FontFamily("Consolas"), FontSize = 13,
            Background = B(Theme.UiPanel2), Foreground = B(Theme.UiText), CaretBrush = B(Theme.UiText), BorderBrush = B(Theme.UiStroke), BorderThickness = new Thickness(1)
        };
        tb.LostFocus += (_, _) => Commit();
        tb.KeyDown += (_, e) => { if (e.Key == Key.Enter) Commit(); };
        void Commit()
        {
            string t = tb.Text.Trim();
            if (!t.StartsWith("#")) t = "#" + t;
            try { ColorConverter.ConvertFromString(t); tb.Text = t; set(t); } catch { tb.Text = value; }
        }
        return tb;
    }

    public static TextBox Input(string text, double width = 260) => new()
    {
        Text = text, Width = width, Padding = new Thickness(10, 7, 10, 7), FontSize = 13, Background = B(Theme.UiPanel2), Foreground = B(Theme.UiText),
        CaretBrush = B(Theme.UiText), BorderBrush = B(Theme.UiStroke), BorderThickness = new Thickness(1), HorizontalAlignment = HorizontalAlignment.Left
    };
}
