using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Win32;
using WinMax.Core;
using WinMax.Shell;
using WinMax.Widgets;
using static WinMax.UI.Ui;

namespace WinMax.UI;

public class MainWindow : Window
{
    static MainWindow? _inst;
    static DispatcherTimer? _applyTimer;

    readonly ContentControl _page = new();
    readonly StackPanel _nav = new();
    string _current = "Home";
    string _widgetTab = "Clock";

    static readonly (string Key, string Icon, string Label)[] Pages =
    {
        ("Home", "🏠", "Home"), ("Widgets", "🧩", "Widgets"), ("Appearance", "🎨", "Appearance"), ("Location", "📍", "Location"),
        ("Taskbar", "▬", "Taskbar"), ("Dock", "🚀", "Dock"), ("Launcher", "🔍", "Start menu"), ("Wallpaper", "🖼️", "Wallpaper"), ("About", "ℹ️", "About"),
    };

    public static void ShowMain()
    {
        if (_inst == null) { _inst = new MainWindow(); _inst.Closed += (_, _) => _inst = null; }
        if (!_inst.IsVisible) _inst.Show();
        if (_inst.WindowState == WindowState.Minimized) _inst.WindowState = WindowState.Normal;
        _inst.Activate();
    }

    MainWindow()
    {
        Title = "WinMax";
        Width = 1060; Height = 720; MinWidth = 860; MinHeight = 560;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        Background = B(Theme.UiBg);
        FontFamily = Font;
        try { Icon = IconCache.Logo(); } catch { }

        var root = new Grid();
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(224) });
        root.ColumnDefinitions.Add(new ColumnDefinition());

        var side = new Border { Background = B(Theme.UiPanel), BorderBrush = B(Theme.UiStroke), BorderThickness = new Thickness(0, 0, 1, 0) };
        var sideStack = new DockPanel { Margin = new Thickness(14) };

        var brand = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(6, 8, 0, 22) };
        brand.Children.Add(new Image { Source = IconCache.Logo(), Width = 34, Height = 34 });
        brand.Children.Add(Txt("WinMax", 20, Theme.UiText, true).Mar(10, 0, 0, 0));
        ((TextBlock)brand.Children[1]).VerticalAlignment = VerticalAlignment.Center;
        DockPanel.SetDock(brand, Dock.Top);
        sideStack.Children.Add(brand);

        var hide = Txt("Closing this window keeps WinMax running in the tray.", 11, Theme.UiSub).Mar(6, 0, 6, 4);
        DockPanel.SetDock(hide, Dock.Bottom);
        sideStack.Children.Add(hide);
        sideStack.Children.Add(_nav);
        side.Child = sideStack;
        Grid.SetColumn(side, 0);
        root.Children.Add(side);

        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = _page, Padding = new Thickness(0) };
        Grid.SetColumn(scroll, 1);
        _page.Margin = new Thickness(32, 26, 32, 26);
        root.Children.Add(scroll);

        Content = root;
        BuildNav();
        Navigate("Home");

        Closing += (s, e) => { e.Cancel = true; Hide(); };   // stay alive in the tray
        SourceInitialized += (_, _) =>
        {
            int dark = Theme.IsLight ? 0 : 1;
            Native.DwmSetWindowAttribute(new WindowInteropHelper(this).Handle, 20, ref dark, sizeof(int));
        };
    }

    void BuildNav()
    {
        _nav.Children.Clear();
        foreach (var p in Pages)
        {
            bool sel = p.Key == _current;
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            row.Children.Add(new TextBlock { Text = p.Icon, FontSize = 15, Width = 28, FontFamily = new FontFamily("Segoe UI Emoji"), Foreground = B(sel ? Colors.White : Theme.UiText), VerticalAlignment = VerticalAlignment.Center });
            row.Children.Add(Txt(p.Label, 14, sel ? Colors.White : Theme.UiText, sel));
            var item = new Border
            {
                Child = row, Padding = new Thickness(12, 10, 12, 10), CornerRadius = new CornerRadius(10), Margin = new Thickness(0, 2, 0, 2), Cursor = Cursors.Hand,
                Background = sel ? Theme.Accent : Brushes.Transparent
            };
            string key = p.Key;
            item.MouseLeftButtonUp += (_, _) => Navigate(key);
            if (!sel)
            {
                item.MouseEnter += (_, _) => item.Background = B(Theme.UiPanel2);
                item.MouseLeave += (_, _) => item.Background = Brushes.Transparent;
            }
            _nav.Children.Add(item);
        }
    }

    void Navigate(string key)
    {
        _current = key;
        BuildNav();
        _page.Content = key switch
        {
            "Widgets" => WidgetsPage(),
            "Appearance" => AppearancePage(),
            "Location" => LocationPage(),
            "Taskbar" => TaskbarPage(),
            "Dock" => DockPage(),
            "Launcher" => LauncherPage(),
            "Wallpaper" => WallpaperPage(),
            "About" => AboutPage(),
            _ => HomePage()
        };
    }

    /// <summary>Debounced "apply everything" so dragging a slider doesn't rebuild widgets 60 times a second.</summary>
    static void ApplySoon(bool theme = false, bool taskbar = false, bool dock = false, bool launcher = false, bool hotkeys = false, bool wallpaper = false)
    {
        SettingsStore.SaveSoon();
        _applyTimer ??= new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(260) };
        _pending.theme |= theme; _pending.taskbar |= taskbar; _pending.dock |= dock; _pending.launcher |= launcher; _pending.hotkeys |= hotkeys; _pending.wallpaper |= wallpaper;
        _applyTimer.Tick -= Flush;
        _applyTimer.Tick += Flush;
        _applyTimer.Stop();
        _applyTimer.Start();
    }

    static (bool theme, bool taskbar, bool dock, bool launcher, bool hotkeys, bool wallpaper) _pending;

    static void Flush(object? s, EventArgs e)
    {
        _applyTimer?.Stop();
        var p = _pending;
        _pending = default;
        try
        {
            if (p.theme) Theme.Refresh();                      // also rebuilds widgets
            if (p.theme || p.taskbar) TaskbarStyler.Apply();
            if (p.theme || p.dock) DockManager.Apply();
            if (p.theme || p.launcher) Launcher.Shutdown();    // rebuilt lazily with the new theme
            if (p.hotkeys) Hotkeys.Apply();
            if (p.wallpaper) WallpaperEngine.Apply();
        }
        catch (Exception ex) { Log.Write(ex); }
    }

    void Rebuild() { Navigate(_current); }

    // ------------------------------------------------------------------ Home
    UIElement HomePage()
    {
        var s = SettingsStore.S;
        var root = Col();
        root.Children.Add(H1("Welcome to WinMax"));
        root.Children.Add(Sub("Widgets, a custom start menu, a restyled taskbar, a dock and live wallpapers. Light on memory, easy to change.").Mar(0, 4, 0, 20));

        var quick = Col(
            Row("Desktop widgets", "Show or hide every widget at once", Switch(s.WidgetsVisible, v => WidgetManager.SetVisible(v))),
            Divider(),
            Row("Start with Windows", "Launch WinMax quietly in the tray at sign-in", Switch(s.StartWithWindows || StartupReg.IsSet(), v => { s.StartWithWindows = v; StartupReg.Set(v); SettingsStore.Save(); })),
            Divider(),
            Row("Custom start menu", "Open with the hotkey, the tray or the dock", Switch(s.LauncherEnabled, v => { s.LauncherEnabled = v; ApplySoon(hotkeys: true, launcher: true); })));
        root.Children.Add(Card(quick));

        var tiles = new WrapPanel();
        void Tile(string icon, string title, string text, string go)
        {
            var t = Col(Txt(icon, 26, Theme.UiText), H2(title).Mar(0, 8, 0, 2), Sub(text));
            var b = new Border { Child = t, Width = 220, Padding = new Thickness(16), Margin = new Thickness(0, 0, 12, 12), CornerRadius = new CornerRadius(14), Cursor = Cursors.Hand, Background = B(Theme.UiPanel), BorderBrush = B(Theme.UiStroke), BorderThickness = new Thickness(1) };
            b.MouseEnter += (_, _) => b.BorderBrush = Theme.Accent;
            b.MouseLeave += (_, _) => b.BorderBrush = B(Theme.UiStroke);
            b.MouseLeftButtonUp += (_, _) => Navigate(go);
            ((TextBlock)t.Children[0]).FontFamily = new FontFamily("Segoe UI Emoji");
            tiles.Children.Add(b);
        }
        Tile("🧩", "Add a widget", "6 widget types, 15 styles each.", "Widgets");
        Tile("🎨", "Pick a look", "Dark, light, glass or colourful.", "Appearance");
        Tile("📍", "Set your location", "Live weather for your city.", "Location");
        Tile("▬", "Style the taskbar", "Clear, glass, tinted and more.", "Taskbar");
        Tile("🚀", "Turn on the dock", "10 dock styles with magnify.", "Dock");
        Tile("🖼️", "Live wallpaper", "4K video, aurora or your image.", "Wallpaper");
        root.Children.Add(tiles);

        if (!s.HasLocation)
            root.Children.Add(Card(Row("Weather needs a location", "Search for your city once and every weather widget goes live.", Btn("Set location", () => Navigate("Location")))));
        return root;
    }

    // ------------------------------------------------------------------ Widgets
    UIElement WidgetsPage()
    {
        var root = Col();
        root.Children.Add(H1("Widgets"));
        root.Children.Add(Sub("Pick a type, then click any style to put it on your desktop. Drag widgets to move them, right-click for size, opacity and style.").Mar(0, 4, 0, 16));

        // type tabs
        var tabs = new WrapPanel { Margin = new Thickness(0, 0, 0, 12) };
        foreach (var type in Catalog.Types)
        {
            string t = type;
            bool sel = t == _widgetTab;
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            row.Children.Add(new TextBlock { Text = Catalog.Icons[t], FontFamily = new FontFamily("Segoe UI Emoji"), FontSize = 14, Margin = new Thickness(0, 0, 6, 0), Foreground = B(sel ? Colors.White : Theme.UiText) });
            row.Children.Add(Txt(t, 13.5, sel ? Colors.White : Theme.UiText, sel));
            var chip = new Border { Child = row, Padding = new Thickness(14, 8, 14, 8), CornerRadius = new CornerRadius(18), Margin = new Thickness(0, 0, 8, 8), Cursor = Cursors.Hand, Background = sel ? Theme.Accent : B(Theme.UiPanel2) };
            chip.MouseLeftButtonUp += (_, _) => { _widgetTab = t; Rebuild(); };
            tabs.Children.Add(chip);
        }
        root.Children.Add(tabs);

        // On your desktop
        var mine = SettingsStore.S.Widgets.Where(w => w.Type == _widgetTab).ToList();
        if (mine.Count > 0)
        {
            var list = Col(H2($"On your desktop ({mine.Count})"));
            foreach (var inst in mine)
            {
                var i = inst;
                var def = Catalog.Get(i.Type, i.Style);
                var row = new Grid { Margin = new Thickness(0, 6, 0, 0) };
                row.ColumnDefinitions.Add(new ColumnDefinition());
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                row.Children.Add(Txt($"{def.Name}   ·   style {i.Style + 1}", 13, Theme.UiText));
                var rm = Btn("Remove", () => { WidgetManager.Remove(i.Id); Rebuild(); }, false);
                Grid.SetColumn(rm, 1);
                row.Children.Add(rm);
                list.Children.Add(row);
            }
            root.Children.Add(Card(list));
        }

        root.Children.Add(H2($"{_widgetTab} styles ({Catalog.Styles(_widgetTab).Count})").Mar(0, 4, 0, 10));
        var wrap = new WrapPanel();
        var styles = Catalog.Styles(_widgetTab);
        for (int idx = 0; idx < styles.Count; idx++) wrap.Children.Add(StyleTile(_widgetTab, idx, styles[idx]));
        root.Children.Add(wrap);
        return root;
    }

    UIElement StyleTile(string type, int idx, StyleDef def)
    {
        UIElement preview;
        try
        {
            var el = def.Build(new Ctx { Preview = true, Inst = new WidgetInstance { Type = type, Style = idx } });
            var card = new Border
            {
                Child = el, Background = def.Card ? Theme.CardBrush : null, BorderBrush = def.Card ? Theme.Stroke : null,
                BorderThickness = def.Card ? new Thickness(1) : new Thickness(0), CornerRadius = new CornerRadius(def.Card ? SettingsStore.S.CornerRadius : 0), IsHitTestVisible = false
            };
            preview = new Viewbox { Child = card, MaxWidth = 196, MaxHeight = 118, Stretch = Stretch.Uniform, StretchDirection = StretchDirection.DownOnly };
        }
        catch (Exception ex) { Log.Write(ex); preview = Txt("preview unavailable", 11, Theme.UiSub); }

        var backdrop = new Border
        {
            Height = 140, CornerRadius = new CornerRadius(10), Child = preview,
            Background = new LinearGradientBrush(new GradientStopCollection
            {
                new GradientStop(Color.FromRgb(0x2B, 0x14, 0x4A), 0), new GradientStop(Color.FromRgb(0x7A, 0x2A, 0x72), 0.55), new GradientStop(Color.FromRgb(0xC2, 0x5B, 0x8E), 1)
            }, 35)
        };
        ((FrameworkElement)preview).HorizontalAlignment = HorizontalAlignment.Center;
        ((FrameworkElement)preview).VerticalAlignment = VerticalAlignment.Center;

        var label = new Grid { Margin = new Thickness(2, 8, 2, 0) };
        label.ColumnDefinitions.Add(new ColumnDefinition());
        label.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        label.Children.Add(Txt($"{idx + 1}. {def.Name}", 12.5, Theme.UiText));
        var add = Txt("＋ Add", 12.5, Theme.AccentC, true);
        Grid.SetColumn(add, 1);
        label.Children.Add(add);

        var tile = new Border
        {
            Width = 224, Margin = new Thickness(0, 0, 14, 14), Padding = new Thickness(10), CornerRadius = new CornerRadius(14), Cursor = Cursors.Hand,
            Background = B(Theme.UiPanel), BorderBrush = B(Theme.UiStroke), BorderThickness = new Thickness(1), Child = Col(backdrop, label)
        };
        tile.MouseEnter += (_, _) => tile.BorderBrush = Theme.Accent;
        tile.MouseLeave += (_, _) => tile.BorderBrush = B(Theme.UiStroke);
        tile.MouseLeftButtonUp += (_, _) =>
        {
            WidgetManager.Add(type, idx);
            Rebuild();
        };
        return tile;
    }

    // ------------------------------------------------------------------ Appearance
    UIElement AppearancePage()
    {
        var s = SettingsStore.S;
        var root = Col(H1("Appearance"), Sub("These settings apply to widgets, the dock, the start menu and this window.").Mar(0, 4, 0, 18));

        var mode = Col(
            Row("Theme", "Dark, light, frosted glass or colourful gradients",
                Chips(new[] { "Dark", "Light", "Glass", "Colorful" }, () => s.ThemeMode, v => { s.ThemeMode = v; Theme.Refresh(false); ApplySoon(theme: true); Background = B(Theme.UiBg); Navigate(_current); })),
            Divider(),
            Row("Glass effect", "Blur is the lightest and works on every Windows 10 and 11 build",
                Chips(new[] { "Blur", "Acrylic" }, () => s.GlassType, v => { s.GlassType = v; ApplySoon(theme: true); })));
        root.Children.Add(Card(mode));

        // accent presets
        var swatches = new WrapPanel { Margin = new Thickness(0, 6, 0, 0) };
        foreach (var p in Theme.Presets)
        {
            var preset = p;
            bool sel = string.Equals(s.Accent, p.A, StringComparison.OrdinalIgnoreCase);
            var sw = new Border
            {
                Width = 56, Height = 56, CornerRadius = new CornerRadius(28), Margin = new Thickness(0, 0, 12, 8), Cursor = Cursors.Hand, ToolTip = p.Name,
                Background = new LinearGradientBrush(Theme.Hex(p.A), Theme.Hex(p.B), 45), BorderThickness = new Thickness(sel ? 3 : 0), BorderBrush = B(Theme.UiText)
            };
            sw.MouseLeftButtonUp += (_, _) => { s.Accent = preset.A; s.Accent2 = preset.B; Theme.Refresh(false); ApplySoon(theme: true); Navigate(_current); };
            swatches.Children.Add(sw);
        }
        var accent = Col(H2("Accent colour"), Sub("Pick a preset or type your own hex colours.").Mar(0, 2, 0, 6), swatches,
            Row("Main accent", null, HexBox(s.Accent, v => { s.Accent = v; Theme.Refresh(false); ApplySoon(theme: true); })),
            Row("Second accent", "Used for gradients in Colourful mode", HexBox(s.Accent2, v => { s.Accent2 = v; Theme.Refresh(false); ApplySoon(theme: true); })));
        root.Children.Add(Card(accent));

        var shape = Col(
            SliderRow("Corner radius", "Roundness of widget cards", 0, 36, s.CornerRadius, v => { s.CornerRadius = v; ApplySoon(theme: true); }, " px"),
            Divider(),
            SliderRow("Card opacity", "Lower = more see-through widgets", 0.2, 1, s.CardOpacity, v => { s.CardOpacity = v; Theme.Refresh(false); ApplySoon(theme: true); }, "", 0.05));
        root.Children.Add(Card(shape));

        var units = Col(
            Row("24-hour clock", null, Switch(s.Use24Hour, v => { s.Use24Hour = v; ApplySoon(theme: true); })),
            Divider(),
            Row("Temperature in °F", "Off = Celsius", Switch(s.Fahrenheit, v => { s.Fahrenheit = v; ApplySoon(theme: true); })),
            Divider(),
            Row("Keep widgets on the desktop layer", "Widgets sit behind your apps. Turn off to float above them.", Switch(s.WidgetsOnDesktopLayer, v => { s.WidgetsOnDesktopLayer = v; ApplySoon(theme: true); })));
        root.Children.Add(Card(units));
        return root;
    }

    // ------------------------------------------------------------------ Location
    UIElement LocationPage()
    {
        var s = SettingsStore.S;
        var root = Col(H1("Location"), Sub("Weather is live from Open-Meteo (free, no account). Only the city you pick is used.").Mar(0, 4, 0, 18));

        var current = Txt(s.HasLocation ? "📍  " + s.LocationName : "No location set yet", 15, Theme.UiText, true);
        var status = Sub(WeatherService.Current != null ? $"Now {WeatherService.Current.Temp:0}°C, {WeatherData.Describe(WeatherService.Current.Code)}" : (WeatherService.LastError ?? ""));
        root.Children.Add(Card(Col(current, status.Mar(0, 4, 0, 0))));

        var box = Input("", 320);
        var results = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
        var msg = Sub("");

        async void Search()
        {
            msg.Text = "Searching…"; results.Children.Clear();
            var list = await WeatherService.SearchAsync(box.Text);
            results.Children.Clear();
            msg.Text = list.Count == 0 ? "No matches. Try the city name only, e.g. \"Pune\"." : "";
            foreach (var r in list)
            {
                var g = r;
                var row = new Border { Padding = new Thickness(12, 9, 12, 9), CornerRadius = new CornerRadius(8), Cursor = Cursors.Hand, Margin = new Thickness(0, 2, 0, 2), Background = B(Theme.UiPanel2), Child = Txt(g.Display, 13.5, Theme.UiText) };
                row.MouseEnter += (_, _) => row.Background = Theme.Accent;
                row.MouseLeave += (_, _) => row.Background = B(Theme.UiPanel2);
                row.MouseLeftButtonUp += async (_, _) => { await Pick(g); };
                results.Children.Add(row);
            }
        }

        async System.Threading.Tasks.Task Pick(GeoResult g)
        {
            s.LocationName = g.Display; s.Lat = g.Lat; s.Lon = g.Lon;
            SettingsStore.Save();
            await WeatherService.RefreshAsync();
            Navigate("Location");
        }

        box.KeyDown += (_, e) => { if (e.Key == Key.Enter) Search(); };
        var searchRow = new StackPanel { Orientation = Orientation.Horizontal };
        searchRow.Children.Add(box);
        var go = Btn("Search", Search); ((FrameworkElement)go).Margin = new Thickness(10, 0, 0, 0);
        searchRow.Children.Add(go);
        var detect = Btn("Detect automatically", async () =>
        {
            msg.Text = "Detecting from your internet connection…";
            var g = await WeatherService.DetectByIpAsync();
            if (g == null) { msg.Text = "Couldn't detect. Please search for your city."; return; }
            await Pick(g);
        }, false);
        ((FrameworkElement)detect).Margin = new Thickness(10, 0, 0, 0);
        searchRow.Children.Add(detect);

        root.Children.Add(Card(Col(H2("Search for your city"), searchRow.Mar(0, 10, 0, 0), msg.Mar(0, 8, 0, 0), results)));
        return root;
    }

    // ------------------------------------------------------------------ Taskbar
    UIElement TaskbarPage()
    {
        var s = SettingsStore.S;
        var root = Col(H1("Taskbar"), Sub("Restyles the real Windows taskbar on every monitor. Pick \"Windows Default\" any time to go back.").Mar(0, 4, 0, 18));

        var wrap = new WrapPanel();
        foreach (var p in TaskbarStyler.Presets)
        {
            var pr = p;
            bool sel = s.TaskbarMode == p.Mode;
            var sample = new Border { Height = 26, CornerRadius = new CornerRadius(6), Background = SampleBrush(p.Mode), Margin = new Thickness(0, 0, 0, 8) };
            var bg = new Border
            {
                Height = 62, CornerRadius = new CornerRadius(8), Padding = new Thickness(10, 0, 10, 0), VerticalAlignment = VerticalAlignment.Top,
                Background = new LinearGradientBrush(Color.FromRgb(0x4B, 0x1D, 0x7A), Color.FromRgb(0xD9, 0x6A, 0x9D), 35), Child = sample
            };
            sample.VerticalAlignment = VerticalAlignment.Bottom; sample.Margin = new Thickness(0, 0, 0, 8);
            var tile = new Border
            {
                Width = 220, Padding = new Thickness(10), Margin = new Thickness(0, 0, 12, 12), CornerRadius = new CornerRadius(14), Cursor = Cursors.Hand,
                Background = B(Theme.UiPanel), BorderBrush = sel ? Theme.Accent : B(Theme.UiStroke), BorderThickness = new Thickness(sel ? 2 : 1),
                Child = Col(bg, H2(p.Name).Mar(2, 8, 0, 0), Sub(p.Desc).Mar(2, 2, 0, 0))
            };
            tile.MouseLeftButtonUp += (_, _) => { s.TaskbarMode = pr.Mode; ApplySoon(taskbar: true); Rebuild(); };
            wrap.Children.Add(tile);
        }
        root.Children.Add(wrap);

        root.Children.Add(Card(Col(
            Row("Tint colour", "Used by Tinted Glass, Soft Blur and Frosted Glass", HexBox(s.TaskbarTint, v => { s.TaskbarTint = v; ApplySoon(taskbar: true); })),
            Divider(),
            SliderRow("Strength", "How strong the tint is", 0.05, 1, s.TaskbarOpacity, v => { s.TaskbarOpacity = v; ApplySoon(taskbar: true); }, "", 0.05))));

        root.Children.Add(Card(Col(
            H2("Choose your own apps"),
            Sub("Windows controls which apps live on its taskbar. To fully control icons, turn on the WinMax Dock and hide the Windows taskbar.").Mar(0, 4, 0, 10),
            Btn("Open Dock settings", () => Navigate("Dock"), false))));
        return root;
    }

    static Brush SampleBrush(string mode) => mode switch
    {
        "Clear" => B(Color.FromArgb(10, 255, 255, 255)),
        "Blur" => B(Color.FromArgb(70, 255, 255, 255)),
        "Acrylic" => B(Color.FromArgb(130, 230, 220, 255)),
        "TintBlur" => B(Color.FromArgb(150, 20, 10, 40)),
        "AccentGlass" => B(Theme.WithAlpha(Theme.AccentC, 0.6)),
        "DarkSolid" => B(Color.FromRgb(0x1C, 0x1A, 0x24)),
        "LightSolid" => B(Color.FromRgb(0xF3, 0xF1, 0xF8)),
        "AccentSolid" => Theme.Accent,
        _ => B(Color.FromRgb(0x20, 0x20, 0x28)),
    };

    // ------------------------------------------------------------------ Dock
    UIElement DockPage()
    {
        var s = SettingsStore.S;
        var root = Col(H1("Dock"), Sub("A floating or full-width dock with the apps you choose. Pair it with a hidden Windows taskbar for a clean desktop.").Mar(0, 4, 0, 18));

        root.Children.Add(Card(Col(
            Row("Enable dock", null, Switch(s.DockEnabled, v => { s.DockEnabled = v; ApplySoon(dock: true); })),
            Divider(),
            Row("Position", null, Chips(new[] { "Bottom", "Top", "Left", "Right" }, () => s.DockPosition, v => { s.DockPosition = v; ApplySoon(dock: true); })),
            Divider(),
            SliderRow("Icon size", null, 28, 80, s.DockIconSize, v => { s.DockIconSize = v; ApplySoon(dock: true); }, " px"),
            Divider(),
            Row("Auto-hide dock", "Slides away until the mouse reaches the screen edge", Switch(s.DockAutoHide, v => { s.DockAutoHide = v; ApplySoon(dock: true); })),
            Divider(),
            Row("Hide the Windows taskbar", "Uses Windows' own auto-hide, so it is safe and reversible", Switch(s.HideSystemTaskbar, v => { s.HideSystemTaskbar = v; ApplySoon(dock: true); })))));

        root.Children.Add(H2("Dock style").Mar(0, 2, 0, 10));
        var wrap = new WrapPanel();
        for (int i = 0; i < DockManager.Styles.Length; i++)
        {
            int idx = i; var st = DockManager.Styles[i];
            bool sel = s.DockStyle == i;
            var strip = new Border { Height = 30, CornerRadius = new CornerRadius(st.Radius > 0 ? 14 : 3), Margin = new Thickness(18, 0, 18, 10), VerticalAlignment = VerticalAlignment.Bottom, Background = DockSample(st) };
            if (st.Neon) { strip.BorderBrush = Theme.Accent; strip.BorderThickness = new Thickness(1.5); }
            var back = new Border { Height = 70, CornerRadius = new CornerRadius(8), Child = strip, Background = new LinearGradientBrush(Color.FromRgb(0x2B, 0x14, 0x4A), Color.FromRgb(0xC2, 0x5B, 0x8E), 35) };
            var tile = new Border
            {
                Width = 220, Padding = new Thickness(10), Margin = new Thickness(0, 0, 12, 12), CornerRadius = new CornerRadius(14), Cursor = Cursors.Hand,
                Background = B(Theme.UiPanel), BorderBrush = sel ? Theme.Accent : B(Theme.UiStroke), BorderThickness = new Thickness(sel ? 2 : 1),
                Child = Col(back, H2($"{i + 1}. {st.Name}").Mar(2, 8, 0, 0))
            };
            tile.MouseLeftButtonUp += (_, _) => { s.DockStyle = idx; ApplySoon(dock: true); Rebuild(); };
            wrap.Children.Add(tile);
        }
        root.Children.Add(wrap);

        // pinned apps
        var apps = Col(H2("Pinned apps"), Sub("The WinMax launcher button is always first. Right-click an icon in the dock to remove it.").Mar(0, 2, 0, 8));
        foreach (var a in s.DockApps.ToList())
        {
            var app = a;
            var g = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(34) });
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.Children.Add(new Image { Source = IconCache.Get(app.Path, 32), Width = 24, Height = 24, HorizontalAlignment = HorizontalAlignment.Left });
            var n = Txt(app.Name, 13.5, Theme.UiText); n.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(n, 1);
            g.Children.Add(n);
            var rm = Btn("Remove", () => { s.DockApps.Remove(app); SettingsStore.Save(); DockManager.Apply(); Rebuild(); }, false);
            Grid.SetColumn(rm, 2); g.Children.Add(rm);
            apps.Children.Add(g);
        }
        apps.Children.Add(Btn("＋ Add an app…", () =>
        {
            var dlg = new OpenFileDialog { Title = "Choose an app", Filter = "Apps and shortcuts|*.exe;*.lnk|All files|*.*" };
            if (dlg.ShowDialog() == true)
            {
                s.DockApps.Add(new PinnedApp { Name = Path.GetFileNameWithoutExtension(dlg.FileName), Path = dlg.FileName });
                SettingsStore.Save(); DockManager.Apply(); Rebuild();
            }
        }).Mar(0, 8, 0, 0));
        root.Children.Add(Card(apps));
        return root;
    }

    static Brush DockSample(DockStyleDef st)
    {
        if (st.Glass) return B(Color.FromArgb(st.Name == "Frosted Light" ? (byte)170 : (byte)90, st.Name == "Frosted Light" ? (byte)245 : (byte)255, st.Name == "Frosted Light" ? (byte)243 : (byte)255, st.Name == "Frosted Light" ? (byte)250 : (byte)255));
        return st.Bg() ?? B(Color.FromArgb(0, 0, 0, 0));
    }

    // ------------------------------------------------------------------ Start menu / launcher
    UIElement LauncherPage()
    {
        var s = SettingsStore.S;
        var root = Col(H1("Start menu"), Sub("A fast app launcher with search, power buttons and a pin-to-dock option.").Mar(0, 4, 0, 18));
        root.Children.Add(Card(Col(
            Row("Enable launcher", null, Switch(s.LauncherEnabled, v => { s.LauncherEnabled = v; ApplySoon(hotkeys: true); })),
            Divider(),
            Row("Layout", "Centered popup, side panel or fullscreen grid", Chips(new[] { "Centered", "Side", "Fullscreen" }, () => s.LauncherLayout, v => { s.LauncherLayout = v; ApplySoon(launcher: true); })),
            Divider(),
            Row("Hotkey", "Works anywhere in Windows", Chips(Enumerable.Range(0, Hotkeys.Options.Length).Select(i => i.ToString()).ToArray(), () => s.HotkeyIndex.ToString(),
                v => { s.HotkeyIndex = int.Parse(v); ApplySoon(hotkeys: true); }, Hotkeys.Options.Select(o => o.Name).ToArray())),
            Divider(),
            Row("Windows key opens WinMax", "Replaces the Windows Start menu when you tap the Windows key alone. Win+shortcuts still work.", Switch(s.WinKeyOpensLauncher, v => { s.WinKeyOpensLauncher = v; ApplySoon(hotkeys: true); })))));
        root.Children.Add(Card(Row("Try it now", "Opens the launcher over your desktop", Btn("Open launcher", () => Launcher.Toggle()))));
        root.Children.Add(Card(Row("Refresh app list", "Use after installing new programs", Btn("Rescan apps", () => Launcher.Reload(), false))));
        return root;
    }

    // ------------------------------------------------------------------ Wallpaper
    UIElement WallpaperPage()
    {
        var s = SettingsStore.S;
        var root = Col(H1("Wallpaper"), Sub("Live video wallpapers (4K supported), animated gradients or a normal picture. Video pauses automatically when a full-screen app is open.").Mar(0, 4, 0, 18));

        var path = Sub(string.IsNullOrEmpty(s.WallpaperPath) ? "No file chosen" : s.WallpaperPath);

        var main = Col(
            Row("Type", null, Chips(new[] { "None", "Image", "Video", "Aurora" }, () => s.WallpaperKind, v => { s.WallpaperKind = v; ApplySoon(wallpaper: true); Rebuild(); }, new[] { "Off", "Image", "Live video", "Animated gradient" })));

        if (s.WallpaperKind is "Image" or "Video")
        {
            bool vid = s.WallpaperKind == "Video";
            main.Children.Add(Divider());
            main.Children.Add(Row(vid ? "Video file" : "Image file", vid ? "MP4, MKV, WMV, AVI, WebM (codecs depend on Windows)" : "JPG, PNG, BMP", Btn("Browse…", () =>
            {
                var dlg = new OpenFileDialog { Title = vid ? "Choose a video" : "Choose an image", Filter = vid ? "Video|*.mp4;*.mkv;*.wmv;*.avi;*.mov;*.webm|All files|*.*" : "Images|*.jpg;*.jpeg;*.png;*.bmp|All files|*.*" };
                if (dlg.ShowDialog() == true) { s.WallpaperPath = dlg.FileName; ApplySoon(wallpaper: true); Rebuild(); }
            })));
            main.Children.Add(path.Mar(0, 4, 0, 0));
        }
        if (s.WallpaperKind == "Aurora")
        {
            main.Children.Add(Divider());
            main.Children.Add(Row("Palette", "Lightweight, runs at a low frame rate",
                Chips(Enumerable.Range(0, WallpaperEngine.AuroraNames.Length).Select(i => i.ToString()).ToArray(), () => s.AuroraPreset.ToString(), v => { s.AuroraPreset = int.Parse(v); ApplySoon(wallpaper: true); }, WallpaperEngine.AuroraNames)));
        }
        root.Children.Add(Card(main));

        if (s.WallpaperKind == "Video")
        {
            root.Children.Add(Card(Col(
                Row("Mute", null, Switch(s.WallpaperMute, v => { s.WallpaperMute = v; ApplySoon(wallpaper: true); })),
                Divider(),
                SliderRow("Volume", null, 0, 1, s.WallpaperVolume, v => { s.WallpaperVolume = v; ApplySoon(wallpaper: true); }, "", 0.05),
                Divider(),
                Row("Pause when an app is full screen or maximised", "Saves CPU, GPU and battery", Switch(s.PauseWhenCovered, v => { s.PauseWhenCovered = v; ApplySoon(wallpaper: true); })),
                Divider(),
                Row("Pause on battery", null, Switch(s.PauseOnBattery, v => { s.PauseOnBattery = v; ApplySoon(wallpaper: true); })))));
        }
        return root;
    }

    // ------------------------------------------------------------------ About
    UIElement AboutPage()
    {
        var root = Col(H1("About WinMax"));
        var logo = new Image { Source = IconCache.Logo(), Width = 96, Height = 96, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 14, 0, 14) };
        root.Children.Add(logo);
        root.Children.Add(Sub("Version 1.0.0 · Windows 10 and Windows 11").Mar(0, 0, 0, 14));
        root.Children.Add(Card(Col(
            Row("Settings folder", "Your layout, notes and reminders are stored here", Btn("Open", () => { try { System.Diagnostics.Process.Start("explorer.exe", SettingsStore.Dir); } catch { } }, false)),
            Divider(),
            Row("Reset widget layout", "Puts the starter widgets back", Btn("Reset", () => { WidgetManager.ResetPositions(); }, false)),
            Divider(),
            Row("Quit WinMax", "Restores the taskbar and stops everything", Btn("Exit", () => Tray.ExitApp())))));
        root.Children.Add(Sub("WinMax never changes system files. Everything it does can be switched off from this window."));
        return root;
    }
}
