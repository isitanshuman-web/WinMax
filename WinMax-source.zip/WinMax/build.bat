@echo off
setlocal
cd /d "%~dp0"
title Building WinMax

echo.
echo  ==== WinMax build ====
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
  echo  .NET 8 SDK not found. Install it from https://dotnet.microsoft.com/download/dotnet/8.0
  echo  then run this file again.
  pause
  exit /b 1
)

echo  [1/2] Publishing app (self-contained: works on any Windows 10/11 PC, no .NET install needed)...
if exist publish rmdir /s /q publish
dotnet publish WinMax.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true ^
  -p:IncludeNativeLibrariesForSelfExtract=true ^
  -p:EnableCompressionInSingleFile=true ^
  -p:DebugType=none -p:DebugSymbols=false ^
  -o publish
if errorlevel 1 (
  echo.
  echo  Build failed. Copy the errors above and send them to me, I'll fix them.
  pause
  exit /b 1
)

echo.
echo  [2/2] Creating the installer (needs Inno Setup 6: https://jrsoftware.org/isdl.php)...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo  Inno Setup not found. The app itself is ready: publish\WinMax.exe
  echo  Install Inno Setup 6 and run this file again to get the Setup.exe.
  pause
  exit /b 0
)
"%ISCC%" installer\WinMax.iss
if errorlevel 1 ( echo  Installer build failed. & pause & exit /b 1 )

echo.
echo  Done!  Installer: dist\WinMax-Setup-1.0.0.exe
echo.
pause
