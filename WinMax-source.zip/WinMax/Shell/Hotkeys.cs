using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using WinMax.Core;

namespace WinMax.Shell;

/// <summary>Global hotkey for the launcher, plus an optional "Windows key opens WinMax" hook.</summary>
public static class Hotkeys
{
    public static readonly (string Name, uint Mods, uint Vk)[] Options =
    {
        ("Ctrl + Alt + Space", 0x2 | 0x1, 0x20),
        ("Alt + Space",        0x1,       0x20),
        ("Ctrl + Space",       0x2,       0x20),
        ("Alt + F1",           0x1,       0x70),
        ("Ctrl + Shift + Space", 0x2 | 0x4, 0x20),
    };

    const int HotkeyId = 0x57AA;
    static HwndSource? _src;
    static IntPtr _hook = IntPtr.Zero;
    static Native.LowLevelKeyboardProc? _proc;   // keep a reference so the GC does not collect the callback
    static bool _winDown, _otherKey;

    public static void Apply()
    {
        var s = SettingsStore.S;

        // --- RegisterHotKey ---
        if (_src == null)
        {
            var p = new HwndSourceParameters("WinMaxHotkeys") { Width = 0, Height = 0, ParentWindow = new IntPtr(-3) /* HWND_MESSAGE */ };
            _src = new HwndSource(p);
            _src.AddHook(WndProc);
        }
        Native.UnregisterHotKey(_src.Handle, HotkeyId);
        if (s.LauncherEnabled)
        {
            var o = Options[Math.Clamp(s.HotkeyIndex, 0, Options.Length - 1)];
            if (!Native.RegisterHotKey(_src.Handle, HotkeyId, o.Mods | 0x4000 /* MOD_NOREPEAT */, o.Vk))
                Log.Write("Could not register hotkey " + o.Name + " (already in use?)");
        }

        // --- Windows key hook ---
        if (s.LauncherEnabled && s.WinKeyOpensLauncher) InstallHook();
        else RemoveHook();
    }

    static IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == Native.WM_HOTKEY && wParam.ToInt32() == HotkeyId)
        {
            Launcher.Toggle();
            handled = true;
        }
        return IntPtr.Zero;
    }

    static void InstallHook()
    {
        if (_hook != IntPtr.Zero) return;
        _proc = HookProc;
        using var cur = Process.GetCurrentProcess();
        _hook = Native.SetWindowsHookEx(Native.WH_KEYBOARD_LL, _proc, Native.GetModuleHandle(cur.MainModule?.ModuleName), 0);
        if (_hook == IntPtr.Zero) Log.Write("Keyboard hook failed");
    }

    static void RemoveHook()
    {
        if (_hook == IntPtr.Zero) return;
        Native.UnhookWindowsHookEx(_hook);
        _hook = IntPtr.Zero;
        _proc = null;
    }

    static IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam)
    {
        try
        {
            if (nCode >= 0)
            {
                var k = Marshal.PtrToStructure<Native.KBDLLHOOKSTRUCT>(lParam);
                bool injected = (k.flags & 0x10) != 0;
                if (!injected)
                {
                    int w = wParam.ToInt32();
                    bool down = w == Native.WM_KEYDOWN || w == Native.WM_SYSKEYDOWN;
                    bool isWin = k.vkCode == 0x5B || k.vkCode == 0x5C;
                    if (isWin)
                    {
                        if (down)
                        {
                            if (!_winDown)
                            {
                                _winDown = true; _otherKey = false;
                                // Send an unassigned key so Windows does not open its own Start menu on release.
                                Native.keybd_event(0xE8, 0, 0, UIntPtr.Zero);
                                Native.keybd_event(0xE8, 0, 2, UIntPtr.Zero);
                            }
                        }
                        else
                        {
                            bool alone = _winDown && !_otherKey;
                            _winDown = false;
                            if (alone) Application.Current.Dispatcher.BeginInvoke(new Action(Launcher.Toggle));
                        }
                    }
                    else if (down && _winDown) _otherKey = true;
                }
            }
        }
        catch { /* never throw out of a hook */ }
        return Native.CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    public static void Shutdown()
    {
        RemoveHook();
        if (_src != null)
        {
            Native.UnregisterHotKey(_src.Handle, HotkeyId);
            _src.Dispose();
            _src = null;
        }
        Launcher.Shutdown();
    }
}
