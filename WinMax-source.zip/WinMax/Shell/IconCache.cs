using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using WinMax.Core;

namespace WinMax.Shell;

/// <summary>Loads high-quality shell icons for .exe / .lnk files and caches them.</summary>
public static class IconCache
{
    [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; }

    [ComImport, Guid("bcc18b79-ba16-442f-80c4-8a59c30c463b"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    interface IShellItemImageFactory
    {
        [PreserveSig] int GetImage(SIZE size, int flags, out IntPtr phbm);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    static extern void SHCreateItemFromParsingName(string path, IntPtr pbc, ref Guid riid, out IShellItemImageFactory ppv);

    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr h);

    static readonly Dictionary<string, ImageSource?> Cache = new(StringComparer.OrdinalIgnoreCase);
    static readonly object Lock = new();

    public static ImageSource? Get(string path, int size = 48)
    {
        lock (Lock)
        {
            if (Cache.TryGetValue(path, out var hit)) return hit;
        }
        ImageSource? img = FromShellItem(path, size) ?? FromAssociatedIcon(path);
        lock (Lock) { Cache[path] = img; }
        return img;
    }

    static ImageSource? FromShellItem(string path, int size)
    {
        try
        {
            Guid iid = new("bcc18b79-ba16-442f-80c4-8a59c30c463b");
            SHCreateItemFromParsingName(path, IntPtr.Zero, ref iid, out var factory);
            int hr = factory.GetImage(new SIZE { cx = size, cy = size }, 0x4 /*SIIGBF_ICONONLY*/, out var hbm);
            if (hr != 0 || hbm == IntPtr.Zero) return null;
            try
            {
                var src = Imaging.CreateBitmapSourceFromHBitmap(hbm, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                src.Freeze();
                return src;
            }
            finally { DeleteObject(hbm); }
        }
        catch { return null; }
    }

    static ImageSource? FromAssociatedIcon(string path)
    {
        try
        {
            if (!File.Exists(path)) return null;
            using var icon = System.Drawing.Icon.ExtractAssociatedIcon(path);
            if (icon == null) return null;
            var src = Imaging.CreateBitmapSourceFromHIcon(icon.Handle, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            src.Freeze();
            return src;
        }
        catch { return null; }
    }

    public static ImageSource? Logo()
    {
        try
        {
            var bmp = new BitmapImage(new Uri("pack://application:,,,/Assets/winmax.png"));
            bmp.Freeze();
            return bmp;
        }
        catch { return null; }
    }
}
