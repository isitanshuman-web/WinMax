using System;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using WinMax.Core;

namespace WinMax.Shell;

public class DockStyleDef
{
    public string Name = "";
    public bool Glass;          // real blur-behind (non-transparent window)
    public double Radius;
    public bool Magnify;
    public bool Flush;          // stretches edge to edge, no margin
    public bool Neon;
    public Func<Brush?> Bg = () => null;
}

public static class DockManager
{
    public static readonly DockStyleDef[] Styles =
    {
        new() { Name = "Floating Glass",   Glass = true,  Radius = 24 },
        new() { Name = "Full-Width Glass", Glass = true,  Radius = 0,  Flush = true },
        new() { Name = "macOS Magnify",    Glass = false, Radius = 22, Magnify = true,  Bg = () => Theme.Solid(Color.FromArgb(150, 28, 26, 36)) },
        new() { Name = "Minimal Icons",    Glass = false, Radius = 0,  Magnify = true,  Bg = () => null },
        new() { Name = "Island",           Glass = false, Radius = 16, Bg = () => Theme.Solid(Color.FromArgb(235, 26, 24, 34)) },
        new() { Name = "Neon Capsule",     Glass = false, Radius = 30, Neon = true,     Bg = () => Theme.Solid(Color.FromArgb(225, 14, 12, 20)) },
        new() { Name = "Flat Dark",        Glass = false, Radius = 0,  Flush = true,    Bg = () => Theme.Solid("#F01C1A24") },
        new() { Name = "Flat Light",       Glass = false, Radius = 0,  Flush = true,    Bg = () => Theme.Solid("#F2F3F1F8") },
        new() { Name = "Colorful",         Glass = false, Radius = 24, Magnify = true,  Bg = () => new LinearGradientBrush(Theme.WithAlpha(Theme.AccentC, 0.9), Theme.WithAlpha(Theme.Accent2C, 0.9), 0) },
        new() { Name = "Frosted Light",    Glass = true,  Radius = 20 },
    };

    static DockWindow? _win;
    static bool? _origAutoHide;

    public static void Apply()
    {
        var s = SettingsStore.S;
        _win?.Close();
        _win = null;

        if (s.HideSystemTaskbar)
        {
            _origAutoHide ??= Native.GetTaskbarAutoHide();
            Native.SetTaskbarAutoHide(true);
        }
        else RestoreTaskbar();

        if (!s.DockEnabled) return;
        _win = new DockWindow();
        _win.Show();
    }

    static void RestoreTaskbar()
    {
        if (_origAutoHide.HasValue) { Native.SetTaskbarAutoHide(_origAutoHide.Value); _origAutoHide = null; }
    }

    public static void Shutdown()
    {
        _win?.Close();
        _win = null;
        RestoreTaskbar();
    }
}

public class DockWindow : Window
{
    readonly DockStyleDef _st;
    readonly bool _vertical;
    readonly string _pos;
    DispatcherTimer? _hideTimer;
    int _awayTicks;
    bool _autoHidden;
    IntPtr _hwnd;

    public DockWindow()
    {
        var s = SettingsStore.S;
        _st = DockManager.Styles[Math.Clamp(s.DockStyle, 0, DockManager.Styles.Length - 1)];
        _pos = s.DockPosition;
        _vertical = _pos is "Left" or "Right";

        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        ShowInTaskbar = false;
        ShowActivated = false;
        Topmost = true;
        AllowsTransparency = !_st.Glass;
        Background = Brushes.Transparent;
        SizeToContent = SizeToContent.WidthAndHeight;
        WindowStartupLocation = WindowStartupLocation.Manual;
        Title = "WinMax Dock";

        BuildContent();
        Loaded += (_, _) => Reposition();
        SizeChanged += (_, _) => { Reposition(); if (_st.Glass && !Native.IsWindows11) RoundWin10(); };
        if (s.DockAutoHide) StartAutoHide();
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _hwnd = new WindowInteropHelper(this).Handle;
        Native.HideFromAltTab(_hwnd);
        if (_st.Glass)
        {
            var src = HwndSource.FromHwnd(_hwnd);
            if (src?.CompositionTarget != null) src.CompositionTarget.BackgroundColor = Colors.Transparent;
            var m = new Native.MARGINS { L = -1, R = -1, T = -1, B = -1 };
            Native.DwmExtendFrameIntoClientArea(_hwnd, ref m);
            bool light = _st.Name == "Frosted Light";
            var tint = light ? Color.FromArgb(0xB0, 0xF5, 0xF3, 0xFA) : Theme.GlassTint;
            Native.SetAccent(_hwnd, SettingsStore.S.GlassType == "Acrylic" ? Native.ACCENT_ACRYLIC : Native.ACCENT_BLUR, tint);
            if (Native.IsWindows11) Native.SetRoundedCorners(_hwnd, _st.Radius > 0);
        }
    }

    void RoundWin10()
    {
        if (_st.Radius <= 0) return;
        var dpi = VisualTreeHelper.GetDpi(this);
        Native.ApplyRegionRounding(_hwnd, (int)(ActualWidth * dpi.DpiScaleX), (int)(ActualHeight * dpi.DpiScaleY), (int)(Math.Min(_st.Radius, 16) * dpi.DpiScaleX));
    }

    void BuildContent()
    {
        var s = SettingsStore.S;
        double icon = Math.Clamp(s.DockIconSize, 24, 96);
        double edge = _st.Flush ? 0 : 10;
        double head = _st.Magnify ? icon * 0.55 : 0;

        var items = new StackPanel { Orientation = _vertical ? Orientation.Vertical : Orientation.Horizontal };
        items.HorizontalAlignment = HorizontalAlignment.Center;
        items.VerticalAlignment = VerticalAlignment.Center;

        // First slot: WinMax launcher
        items.Children.Add(MakeItem("Launcher", IconCache.Logo(), icon, () => Launcher.Toggle(), null));
        foreach (var app in s.DockApps.ToList())
        {
            var a = app;
            items.Children.Add(MakeItem(a.Name, IconCache.Get(a.Path), icon, () => Open(a.Path), a));
        }

        var shell = new Border
        {
            Child = items,
            Padding = new Thickness(_vertical ? 8 : 12, _vertical ? 12 : 8, _vertical ? 8 : 12, _vertical ? 12 : 8),
            CornerRadius = new CornerRadius(_st.Radius),
            Background = _st.Glass ? new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)) : _st.Bg(),
        };
        if (_st.Neon)
        {
            shell.BorderBrush = Theme.Accent; shell.BorderThickness = new Thickness(1.5);
            shell.Effect = new System.Windows.Media.Effects.DropShadowEffect { Color = Theme.AccentC, BlurRadius = 20, ShadowDepth = 0, Opacity = 0.85 };
        }
        else if (!_st.Glass && _st.Bg() != null)
        {
            shell.BorderBrush = Theme.Solid(Color.FromArgb(40, 255, 255, 255)); shell.BorderThickness = new Thickness(1);
        }

        var root = new Grid();
        root.Children.Add(shell);

        var wa = SystemParameters.WorkArea;
        switch (_pos)
        {
            case "Top":
                root.Margin = new Thickness(0, edge, 0, head);
                shell.VerticalAlignment = VerticalAlignment.Top; break;
            case "Left":
                root.Margin = new Thickness(edge, 0, head, 0);
                shell.HorizontalAlignment = HorizontalAlignment.Left; break;
            case "Right":
                root.Margin = new Thickness(head, 0, edge, 0);
                shell.HorizontalAlignment = HorizontalAlignment.Right; break;
            default:
                root.Margin = new Thickness(0, head, 0, edge);
                shell.VerticalAlignment = VerticalAlignment.Bottom; break;
        }

        if (_st.Flush)
        {
            if (_vertical) { SizeToContent = SizeToContent.Width; Height = wa.Height; shell.VerticalAlignment = VerticalAlignment.Stretch; }
            else { SizeToContent = SizeToContent.Height; Width = wa.Width; shell.HorizontalAlignment = HorizontalAlignment.Stretch; }
        }
        Content = root;
    }

    FrameworkElement MakeItem(string name, ImageSource? img, double size, Action click, PinnedApp? app)
    {
        var image = new Image
        {
            Source = img, Width = size, Height = size, Stretch = Stretch.Uniform,
            RenderTransformOrigin = _pos switch { "Top" => new Point(0.5, 0), "Left" => new Point(0, 0.5), "Right" => new Point(1, 0.5), _ => new Point(0.5, 1) },
            RenderTransform = new ScaleTransform(1, 1),
            SnapsToDevicePixels = false
        };
        RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);
        if (_st.Name == "Minimal Icons") image.Effect = new System.Windows.Media.Effects.DropShadowEffect { BlurRadius = 10, ShadowDepth = 1, Opacity = 0.6 };

        var holder = new Border { Child = image, Padding = new Thickness(6), Background = Brushes.Transparent, Cursor = Cursors.Hand, ToolTip = name };

        if (_st.Magnify)
        {
            holder.MouseEnter += (_, _) => Animate(image, 1.45);
            holder.MouseLeave += (_, _) => Animate(image, 1.0);
        }
        else
        {
            holder.MouseEnter += (_, _) => holder.Background = Theme.Solid(Color.FromArgb(40, 255, 255, 255));
            holder.MouseLeave += (_, _) => holder.Background = Brushes.Transparent;
            holder.CornerRadius = new CornerRadius(10);
        }
        holder.MouseLeftButtonUp += (_, _) => click();

        if (app != null)
        {
            var menu = new ContextMenu();
            var rm = new MenuItem { Header = "Remove from dock" };
            rm.Click += (_, _) =>
            {
                SettingsStore.S.DockApps.RemoveAll(a => a.Path == app.Path);
                SettingsStore.Save();
                DockManager.Apply();
            };
            menu.Items.Add(rm);
            holder.ContextMenu = menu;
        }
        return holder;
    }

    static void Animate(Image img, double to)
    {
        if (img.RenderTransform is not ScaleTransform st) return;
        var anim = new DoubleAnimation(to, TimeSpan.FromMilliseconds(120)) { EasingFunction = new QuadraticEase() };
        st.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
        st.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
    }

    static void Open(string path)
    {
        try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); }
        catch (Exception ex) { Log.Write(ex); }
    }

    void Reposition()
    {
        var wa = SystemParameters.WorkArea;
        double w = ActualWidth, h = ActualHeight;
        if (w <= 0 || h <= 0) return;
        switch (_pos)
        {
            case "Top": Left = wa.Left + (wa.Width - w) / 2; Top = wa.Top; break;
            case "Left": Left = wa.Left; Top = wa.Top + (wa.Height - h) / 2; break;
            case "Right": Left = wa.Right - w; Top = wa.Top + (wa.Height - h) / 2; break;
            default: Left = wa.Left + (wa.Width - w) / 2; Top = wa.Bottom - h; break;
        }
        if (_st.Flush && !_vertical) Left = wa.Left;
        if (_st.Flush && _vertical) Top = wa.Top;
    }

    // ---- Auto-hide (polling, only runs when enabled) ----
    void StartAutoHide()
    {
        _hideTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(180) };
        _hideTimer.Tick += (_, _) =>
        {
            if (!Native.GetCursorPos(out var p)) return;
            var src = PresentationSource.FromVisual(this);
            if (src?.CompositionTarget == null) return;
            var pt = src.CompositionTarget.TransformFromDevice.Transform(new Point(p.X, p.Y));
            double sw = SystemParameters.PrimaryScreenWidth, sh = SystemParameters.PrimaryScreenHeight;
            bool atEdge = _pos switch { "Top" => pt.Y <= 1, "Left" => pt.X <= 1, "Right" => pt.X >= sw - 2, _ => pt.Y >= sh - 2 };
            bool inside = pt.X >= Left - 8 && pt.X <= Left + ActualWidth + 8 && pt.Y >= Top - 8 && pt.Y <= Top + ActualHeight + 8;
            if (_autoHidden && atEdge) { Show(); _autoHidden = false; _awayTicks = 0; }
            else if (!_autoHidden)
            {
                _awayTicks = inside ? 0 : _awayTicks + 1;
                if (_awayTicks > 4) { Hide(); _autoHidden = true; }
            }
        };
        _hideTimer.Start();
    }

    protected override void OnClosed(EventArgs e)
    {
        _hideTimer?.Stop();
        base.OnClosed(e);
    }
}
