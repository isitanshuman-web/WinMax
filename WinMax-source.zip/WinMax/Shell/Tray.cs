using System;
using System.Drawing;
using System.Windows;
using WinMax.Core;
using WinMax.Widgets;

namespace WinMax.Shell;

public static class Tray
{
    static System.Windows.Forms.NotifyIcon? _ni;

    public static void Init()
    {
        System.Drawing.Icon? icon = null;
        try { icon = System.Drawing.Icon.ExtractAssociatedIcon(Environment.ProcessPath!); } catch { }

        _ni = new System.Windows.Forms.NotifyIcon { Icon = icon ?? SystemIcons.Application, Text = "WinMax", Visible = true };
        _ni.MouseClick += (_, e) =>
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) UI.MainWindow.ShowMain();
        };

        var menu = new System.Windows.Forms.ContextMenuStrip();
        menu.Items.Add("Open WinMax", null, (_, _) => UI.MainWindow.ShowMain());
        menu.Items.Add("Open launcher", null, (_, _) => Launcher.Toggle());
        var toggle = menu.Items.Add("Show / hide widgets", null, (_, _) => WidgetManager.SetVisible(!SettingsStore.S.WidgetsVisible));
        menu.Items.Add("-");
        menu.Items.Add("Exit WinMax", null, (_, _) => ExitApp());
        _ni.ContextMenuStrip = menu;
    }

    public static void Notify(string title, string text)
    {
        try { _ni?.ShowBalloonTip(6000, title, text, System.Windows.Forms.ToolTipIcon.Info); } catch { }
    }

    public static void ExitApp()
    {
        try
        {
            SettingsStore.Save();
            TaskbarStyler.Restore();
            DockManager.Shutdown();
            WallpaperEngine.Stop();
            Hotkeys.Shutdown();
            if (_ni != null) { _ni.Visible = false; _ni.Dispose(); _ni = null; }
        }
        catch (Exception ex) { Log.Write(ex); }
        Application.Current.Shutdown();
    }
}
