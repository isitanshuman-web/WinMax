using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using WinMax.Core;

namespace WinMax.Shell;

/// <summary>Live wallpapers: video (any size incl. 4K), animated "aurora" gradients, or a static image.</summary>
public static class WallpaperEngine
{
    public static readonly string[] AuroraNames = { "Violet Dream", "Rose Smoke", "Ocean Night", "Emerald Mist", "Sunset Glow", "Monochrome" };

    static readonly (string bg1, string bg2, string[] blobs)[] Auroras =
    {
        ("#12091F", "#2A0E3F", new[] { "#7C3AED", "#EC4899", "#6366F1", "#F472B6" }),
        ("#14060C", "#220A14", new[] { "#F9A8D4", "#EC4899", "#BE185D", "#FDE4EE" }),
        ("#03101F", "#06203A", new[] { "#38BDF8", "#2563EB", "#22D3EE", "#4F46E5" }),
        ("#04140E", "#082A1E", new[] { "#34D399", "#059669", "#A7F3D0", "#0EA5E9" }),
        ("#1A0A08", "#2B0F10", new[] { "#FB923C", "#F43F5E", "#FBBF24", "#A855F7" }),
        ("#0B0B0E", "#16161B", new[] { "#FFFFFF", "#9CA3AF", "#6B7280", "#D1D5DB" }),
    };

    static readonly List<Window> Windows = new();
    static readonly List<MediaElement> Players = new();
    static DispatcherTimer? _guard;

    public static void Apply()
    {
        Stop();
        var s = SettingsStore.S;
        try
        {
            switch (s.WallpaperKind)
            {
                case "Image": SetStaticImage(s.WallpaperPath); break;
                case "Video": if (File.Exists(s.WallpaperPath)) StartOnEachScreen(scr => MakeVideo(s.WallpaperPath, s)); break;
                case "Aurora": StartOnEachScreen(scr => MakeAurora(s.AuroraPreset)); break;
            }
        }
        catch (Exception ex) { Log.Write(ex); }
    }

    public static void Stop()
    {
        _guard?.Stop();
        foreach (var p in Players) { try { p.Stop(); p.Close(); } catch { } }
        Players.Clear();
        foreach (var w in Windows) { try { w.Close(); } catch { } }
        Windows.Clear();
    }

    static void SetStaticImage(string path)
    {
        if (!File.Exists(path)) return;
        string dir = Path.Combine(SettingsStore.Dir, "wallpaper");
        Directory.CreateDirectory(dir);
        string dest = Path.Combine(dir, "current" + Path.GetExtension(path));
        File.Copy(path, dest, true);
        Native.SystemParametersInfo(20 /*SPI_SETDESKWALLPAPER*/, 0, dest, 3 /*UPDATEINIFILE|SENDCHANGE*/);
    }

    static void StartOnEachScreen(Func<System.Windows.Forms.Screen, UIElement> factory)
    {
        IntPtr host = Native.GetDesktopHost();
        Native.GetWindowRect(host, out var hostRect);

        foreach (var scr in System.Windows.Forms.Screen.AllScreens)
        {
            var win = new Window
            {
                WindowStyle = WindowStyle.None, ResizeMode = ResizeMode.NoResize, ShowInTaskbar = false, ShowActivated = false,
                AllowsTransparency = false, Background = Brushes.Black, Title = "WinMax Wallpaper",
                Left = scr.Bounds.X, Top = scr.Bounds.Y, Width = 400, Height = 300,
                Content = factory(scr)
            };
            win.Show();
            IntPtr hwnd = new WindowInteropHelper(win).Handle;
            Native.HideFromAltTab(hwnd);
            if (host != IntPtr.Zero)
            {
                Native.SetParent(hwnd, host);
                Native.MoveWindow(hwnd, scr.Bounds.X - hostRect.Left, scr.Bounds.Y - hostRect.Top, scr.Bounds.Width, scr.Bounds.Height, true);
            }
            else
            {
                Native.MoveWindow(hwnd, scr.Bounds.X, scr.Bounds.Y, scr.Bounds.Width, scr.Bounds.Height, true);
                Native.SendToBottom(hwnd);
            }
            Windows.Add(win);
        }

        if (Players.Count > 0)
        {
            _guard ??= new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            _guard.Tick -= GuardTick;
            _guard.Tick += GuardTick;
            _guard.Start();
        }
    }

    static bool _paused;
    static void GuardTick(object? s, EventArgs e)
    {
        var set = SettingsStore.S;
        bool pause = false;
        if (set.PauseWhenCovered && Native.IsCoveredByForegroundApp(true)) pause = true;
        if (set.PauseOnBattery && System.Windows.Forms.SystemInformation.PowerStatus.PowerLineStatus == System.Windows.Forms.PowerLineStatus.Offline) pause = true;
        if (pause == _paused) return;
        _paused = pause;
        foreach (var p in Players) { try { if (pause) p.Pause(); else p.Play(); } catch { } }
    }

    static UIElement MakeVideo(string path, AppSettings s)
    {
        var me = new MediaElement
        {
            LoadedBehavior = MediaState.Manual, UnloadedBehavior = MediaState.Manual,
            Stretch = Stretch.UniformToFill, IsMuted = s.WallpaperMute, Volume = Math.Clamp(s.WallpaperVolume, 0, 1),
            ScrubbingEnabled = false, Source = new Uri(path)
        };
        me.MediaEnded += (_, _) => { me.Position = TimeSpan.Zero; me.Play(); };
        me.MediaFailed += (_, e) => Log.Write("Video wallpaper failed: " + e.ErrorException?.Message);
        me.Loaded += (_, _) => me.Play();
        Players.Add(me);
        return me;
    }

    static UIElement MakeAurora(int preset)
    {
        var p = Auroras[Math.Clamp(preset, 0, Auroras.Length - 1)];
        var canvas = new Canvas { Width = 1920, Height = 1080, ClipToBounds = true,
            Background = new LinearGradientBrush(Theme.Hex(p.bg1), Theme.Hex(p.bg2), 45) };

        var rnd = new Random(preset * 97 + 13);
        for (int i = 0; i < p.blobs.Length; i++)
        {
            double size = 900 + rnd.Next(0, 500);
            var c = Theme.Hex(p.blobs[i]);
            var brush = new RadialGradientBrush();
            brush.GradientStops.Add(new GradientStop(Color.FromArgb(i == 3 && preset == 5 ? (byte)90 : (byte)200, c.R, c.G, c.B), 0));
            brush.GradientStops.Add(new GradientStop(Color.FromArgb(0, c.R, c.G, c.B), 1));
            var blob = new System.Windows.Shapes.Ellipse { Width = size, Height = size, Fill = brush, RenderTransform = new TranslateTransform() };
            Canvas.SetLeft(blob, rnd.Next(-200, 1500));
            Canvas.SetTop(blob, rnd.Next(-300, 700));
            canvas.Children.Add(blob);

            var tt = (TranslateTransform)blob.RenderTransform;
            tt.BeginAnimation(TranslateTransform.XProperty, Drift(rnd, 600, 14 + rnd.Next(0, 14)));
            tt.BeginAnimation(TranslateTransform.YProperty, Drift(rnd, 400, 16 + rnd.Next(0, 14)));
        }
        return new Viewbox { Stretch = Stretch.UniformToFill, Child = canvas };
    }

    static DoubleAnimation Drift(Random rnd, double range, double seconds)
    {
        var a = new DoubleAnimation(-range / 2 + rnd.NextDouble() * 80, range / 2 - rnd.NextDouble() * 80, TimeSpan.FromSeconds(seconds))
        {
            AutoReverse = true, RepeatBehavior = RepeatBehavior.Forever, EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut }
        };
        Timeline.SetDesiredFrameRate(a, 20);   // low frame rate keeps CPU/GPU use tiny
        return a;
    }
}
