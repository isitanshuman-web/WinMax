using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using WinMax.Core;

namespace WinMax.Shell;

public record AppEntry(string Name, string Path);

/// <summary>Custom start menu / app launcher. Opens with a hotkey, the Windows key (optional), the tray or the dock.</summary>
public class Launcher : Window
{
    static Launcher? _instance;
    static List<AppEntry>? _apps;
    static Task? _loading;

    readonly TextBox _search;
    readonly WrapPanel _grid;
    readonly ScrollViewer _scroll;
    readonly TextBlock _title;
    IntPtr _hwnd;
    bool _closing;

    public static void Toggle()
    {
        if (!SettingsStore.S.LauncherEnabled) return;
        _instance ??= new Launcher();
        if (_instance.IsVisible) _instance.HideLauncher();
        else _instance.ShowLauncher();
    }

    public static void Shutdown()
    {
        if (_instance != null)
        {
            _instance._closing = true;
            _instance.Close();
            _instance = null;
        }
    }

    static void EnsureLoaded()
    {
        _loading ??= Task.Run(() => { _apps = Scan(); });
    }

    public static void Reload() { _apps = null; _loading = null; EnsureLoaded(); }

    static List<AppEntry> Scan()
    {
        var dirs = new[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu), "Programs"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs"),
        };
        var found = new Dictionary<string, AppEntry>(StringComparer.OrdinalIgnoreCase);
        foreach (var d in dirs.Where(Directory.Exists))
        {
            try
            {
                foreach (var f in Directory.EnumerateFiles(d, "*.lnk", SearchOption.AllDirectories))
                {
                    string name = Path.GetFileNameWithoutExtension(f);
                    if (name.Contains("uninstall", StringComparison.OrdinalIgnoreCase)) continue;
                    if (!found.ContainsKey(name)) found[name] = new AppEntry(name, f);
                }
            }
            catch (Exception ex) { Log.Write(ex); }
        }
        return found.Values.OrderBy(a => a.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    Launcher()
    {
        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        ShowInTaskbar = false;
        Topmost = true;
        AllowsTransparency = false;
        Background = Brushes.Transparent;
        Title = "WinMax Launcher";

        _search = new TextBox
        {
            FontSize = 16, Background = Brushes.Transparent, BorderThickness = new Thickness(0),
            Foreground = Theme.Text, CaretBrush = Theme.Text, VerticalContentAlignment = VerticalAlignment.Center, Padding = new Thickness(8, 0, 8, 0)
        };
        _search.TextChanged += (_, _) => Fill();
        _search.KeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter) { var first = Filtered().FirstOrDefault(); if (first != null) Launch(first); }
            else if (e.Key == Key.Escape) HideLauncher();
        };
        PreviewKeyDown += (_, e) => { if (e.Key == Key.Escape) HideLauncher(); };

        _title = V("🔍", 16);
        var searchBox = new Border
        {
            Height = 44, CornerRadius = new CornerRadius(22), Padding = new Thickness(14, 0, 14, 0),
            Background = Theme.Solid(Color.FromArgb(Theme.IsLight ? (byte)30 : (byte)38, Theme.IsLight ? (byte)0 : (byte)255, Theme.IsLight ? (byte)0 : (byte)255, Theme.IsLight ? (byte)0 : (byte)255)),
            Child = new DockPanel()
        };
        var dp = (DockPanel)searchBox.Child;
        DockPanel.SetDock(_title, Dock.Left);
        dp.Children.Add(_title);
        dp.Children.Add(_search);

        _grid = new WrapPanel { Margin = new Thickness(0, 6, 0, 6) };
        _scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = _grid, Margin = new Thickness(0, 10, 0, 10) };

        var power = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        power.Children.Add(PowerBtn("⚙", "WinMax settings", () => { HideLauncher(); UI.MainWindow.ShowMain(); }));
        power.Children.Add(PowerBtn("🔒", "Lock", () => { HideLauncher(); PowerActions.Lock(); }));
        power.Children.Add(PowerBtn("🌙", "Sleep", () => { HideLauncher(); PowerActions.Sleep(); }));
        power.Children.Add(PowerBtn("⟳", "Restart", () => { HideLauncher(); PowerActions.Restart(); }));
        power.Children.Add(PowerBtn("⏻", "Shut down", () => { HideLauncher(); PowerActions.Shutdown(); }));

        var user = new TextBlock { Text = "👤  " + Environment.UserName, Foreground = Theme.Sub, FontSize = 13, VerticalAlignment = VerticalAlignment.Center };
        var bottom = new DockPanel { LastChildFill = true };
        DockPanel.SetDock(power, Dock.Right);
        bottom.Children.Add(power);
        bottom.Children.Add(user);

        var root = new DockPanel { Margin = new Thickness(22) };
        DockPanel.SetDock(searchBox, Dock.Top);
        DockPanel.SetDock(bottom, Dock.Bottom);
        root.Children.Add(searchBox);
        root.Children.Add(bottom);
        root.Children.Add(_scroll);
        Content = root;

        Deactivated += (_, _) => { if (!_closing) HideLauncher(); };
    }

    static TextBlock V(string t, double size) => new() { Text = t, FontSize = size, VerticalAlignment = VerticalAlignment.Center, FontFamily = new FontFamily("Segoe UI Emoji") };

    UIElement PowerBtn(string glyph, string tip, Action click)
    {
        var b = new Border
        {
            Width = 38, Height = 38, CornerRadius = new CornerRadius(19), Margin = new Thickness(4, 0, 0, 0), Cursor = Cursors.Hand,
            Background = Brushes.Transparent, ToolTip = tip,
            Child = new TextBlock { Text = glyph, FontSize = 16, Foreground = Theme.Text, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, FontFamily = new FontFamily("Segoe UI Symbol") }
        };
        b.MouseEnter += (_, _) => b.Background = Theme.Solid(Color.FromArgb(50, 255, 255, 255));
        b.MouseLeave += (_, _) => b.Background = Brushes.Transparent;
        b.MouseLeftButtonUp += (_, _) => click();
        return b;
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _hwnd = new WindowInteropHelper(this).Handle;
        Native.HideFromAltTab(_hwnd);
        var src = HwndSource.FromHwnd(_hwnd);
        if (src?.CompositionTarget != null) src.CompositionTarget.BackgroundColor = Colors.Transparent;
        var m = new Native.MARGINS { L = -1, R = -1, T = -1, B = -1 };
        Native.DwmExtendFrameIntoClientArea(_hwnd, ref m);
        var tint = Theme.IsLight ? Color.FromArgb(0xC8, 0xF5, 0xF3, 0xFA) : Color.FromArgb(0xB8, 0x12, 0x10, 0x1C);
        Native.SetAccent(_hwnd, SettingsStore.S.GlassType == "Acrylic" ? Native.ACCENT_ACRYLIC : Native.ACCENT_BLUR, tint);
        if (Native.IsWindows11) Native.SetRoundedCorners(_hwnd, SettingsStore.S.LauncherLayout != "Fullscreen");
        else SizeChanged += (_, _) =>
        {
            if (SettingsStore.S.LauncherLayout == "Fullscreen") return;
            var dpi = VisualTreeHelper.GetDpi(this);
            Native.ApplyRegionRounding(_hwnd, (int)(ActualWidth * dpi.DpiScaleX), (int)(ActualHeight * dpi.DpiScaleY), (int)(14 * dpi.DpiScaleX));
        };
    }

    void ApplyLayout()
    {
        var wa = SystemParameters.WorkArea;
        switch (SettingsStore.S.LauncherLayout)
        {
            case "Side":
                Width = 440; Height = wa.Height - 24; Left = wa.Right - Width - 12; Top = wa.Top + 12; break;
            case "Fullscreen":
                Width = wa.Width; Height = wa.Height; Left = wa.Left; Top = wa.Top; break;
            default:
                Width = Math.Min(800, wa.Width - 40); Height = Math.Min(640, wa.Height - 40);
                Left = wa.Left + (wa.Width - Width) / 2; Top = wa.Bottom - Height - 14; break;
        }
    }

    void ShowLauncher()
    {
        ApplyLayout();
        _search.Text = "";
        EnsureLoaded();
        Fill();
        Show();
        Activate();
        _search.Focus();
        Keyboard.Focus(_search);
        if (_apps == null) _ = RefreshWhenLoaded();
    }

    async Task RefreshWhenLoaded()
    {
        if (_loading != null) await _loading;
        if (IsVisible) Fill();
    }

    void HideLauncher()
    {
        _grid.Children.Clear();   // release visuals while hidden to stay light
        Hide();
    }

    IEnumerable<AppEntry> Filtered()
    {
        var all = _apps ?? new List<AppEntry>();
        string q = _search.Text.Trim();
        if (q.Length == 0) return all;
        return all.Where(a => a.Name.Contains(q, StringComparison.CurrentCultureIgnoreCase))
                  .OrderByDescending(a => a.Name.StartsWith(q, StringComparison.CurrentCultureIgnoreCase))
                  .ThenBy(a => a.Name);
    }

    void Fill()
    {
        _grid.Children.Clear();
        if (_apps == null)
        {
            _grid.Children.Add(new TextBlock { Text = "Loading apps…", Foreground = Theme.Sub, FontSize = 14, Margin = new Thickness(8) });
            return;
        }
        bool big = SettingsStore.S.LauncherLayout == "Fullscreen";
        double tile = big ? 120 : 98, icon = big ? 56 : 44;
        foreach (var app in Filtered())
        {
            var a = app;
            var img = new Image { Width = icon, Height = icon, Source = IconCache.Get(a.Path, 64) };
            RenderOptions.SetBitmapScalingMode(img, BitmapScalingMode.HighQuality);
            var name = new TextBlock { Text = a.Name, Foreground = Theme.Text, FontSize = 12, TextAlignment = TextAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis, MaxWidth = tile - 12, Margin = new Thickness(0, 6, 0, 0) };
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            sp.Children.Add(img); sp.Children.Add(name);
            var t = new Border { Width = tile, Height = tile * 0.95, CornerRadius = new CornerRadius(12), Background = Brushes.Transparent, Cursor = Cursors.Hand, Child = sp, ToolTip = a.Name };
            sp.VerticalAlignment = VerticalAlignment.Center;
            t.MouseEnter += (_, _) => t.Background = Theme.Solid(Color.FromArgb(45, 255, 255, 255));
            t.MouseLeave += (_, _) => t.Background = Brushes.Transparent;
            t.MouseLeftButtonUp += (_, _) => Launch(a);

            var menu = new ContextMenu();
            var pin = new MenuItem { Header = "Pin to dock" };
            pin.Click += (_, _) =>
            {
                if (!SettingsStore.S.DockApps.Any(x => x.Path == a.Path))
                {
                    SettingsStore.S.DockApps.Add(new PinnedApp { Name = a.Name, Path = a.Path });
                    SettingsStore.Save();
                    DockManager.Apply();
                }
            };
            menu.Items.Add(pin);
            var open = new MenuItem { Header = "Open file location" };
            open.Click += (_, _) => { try { Process.Start("explorer.exe", $"/select,\"{a.Path}\""); } catch { } };
            menu.Items.Add(open);
            t.ContextMenu = menu;
            _grid.Children.Add(t);
        }
        if (_grid.Children.Count == 0)
            _grid.Children.Add(new TextBlock { Text = "No matching apps", Foreground = Theme.Sub, FontSize = 14, Margin = new Thickness(8) });
    }

    void Launch(AppEntry a)
    {
        HideLauncher();
        try { Process.Start(new ProcessStartInfo(a.Path) { UseShellExecute = true }); }
        catch (Exception ex) { Log.Write(ex); }
    }
}
