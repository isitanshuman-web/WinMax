using System;
using System.Windows.Media;
using System.Windows.Threading;
using WinMax.Core;

namespace WinMax.Shell;

/// <summary>Restyles the real Windows taskbar (transparent / blur / acrylic / tinted / solid) on Windows 10 and 11.</summary>
public static class TaskbarStyler
{
    public static readonly (string Mode, string Name, string Desc)[] Presets =
    {
        ("Default",     "Windows Default",  "Leave the taskbar alone"),
        ("Clear",       "Clear",            "Fully transparent, icons float on the wallpaper"),
        ("Blur",        "Soft Blur",        "Light blur, barely tinted"),
        ("Acrylic",     "Frosted Glass",    "Acrylic frosted glass"),
        ("TintBlur",    "Tinted Glass",     "Blur with your tint colour"),
        ("AccentGlass", "Accent Glass",     "Blur tinted with the accent colour"),
        ("DarkSolid",   "Dark Solid",       "Opaque dark"),
        ("LightSolid",  "Light Solid",      "Opaque light"),
        ("AccentSolid", "Accent Solid",     "Opaque accent colour"),
    };

    static DispatcherTimer? _timer;
    static bool _active;

    public static void Apply()
    {
        var s = SettingsStore.S;
        if (s.TaskbarMode == "Default")
        {
            if (_active) Restore();
            return;
        }
        _active = true;
        ApplyOnce();
        _timer ??= new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _timer.Tick -= OnTick;
        _timer.Tick += OnTick;
        _timer.Start();
    }

    static void OnTick(object? s, EventArgs e) => ApplyOnce();

    static (int state, Color color) Resolve()
    {
        var s = SettingsStore.S;
        var tint = Theme.Hex(s.TaskbarTint);
        byte a = (byte)Math.Clamp(s.TaskbarOpacity * 255, 1, 255);
        return s.TaskbarMode switch
        {
            "Clear" => (Native.ACCENT_TRANSPARENT, Color.FromArgb(1, 0, 0, 0)),
            "Blur" => (Native.ACCENT_BLUR, Color.FromArgb((byte)Math.Clamp(a * 0.25, 1, 255), tint.R, tint.G, tint.B)),
            "Acrylic" => (Native.ACCENT_ACRYLIC, Color.FromArgb((byte)Math.Max(a, (byte)40), tint.R, tint.G, tint.B)),
            "TintBlur" => (Native.ACCENT_BLUR, Color.FromArgb(a, tint.R, tint.G, tint.B)),
            "AccentGlass" => (Native.ACCENT_BLUR, Color.FromArgb(a, Theme.AccentC.R, Theme.AccentC.G, Theme.AccentC.B)),
            "DarkSolid" => (Native.ACCENT_GRADIENT, Color.FromArgb(255, 0x1C, 0x1A, 0x24)),
            "LightSolid" => (Native.ACCENT_GRADIENT, Color.FromArgb(255, 0xF3, 0xF1, 0xF8)),
            "AccentSolid" => (Native.ACCENT_GRADIENT, Color.FromArgb(255, Theme.AccentC.R, Theme.AccentC.G, Theme.AccentC.B)),
            _ => (Native.ACCENT_DISABLED, Colors.Transparent)
        };
    }

    static void ApplyOnce()
    {
        try
        {
            var (state, color) = Resolve();
            foreach (var h in Native.TaskbarWindows()) Native.SetAccent(h, state, color);
        }
        catch (Exception ex) { Log.Write(ex); }
    }

    public static void Restore()
    {
        _timer?.Stop();
        _active = false;
        try
        {
            foreach (var h in Native.TaskbarWindows()) Native.SetAccent(h, Native.ACCENT_DISABLED, Colors.Transparent);
        }
        catch (Exception ex) { Log.Write(ex); }
    }
}
