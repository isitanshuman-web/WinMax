# WinMax

Widgets, a custom start menu, a restyled taskbar, a dock and live wallpapers for **Windows 10 and Windows 11**.
Native app (C# / WPF on .NET 8). No web view, no HTML, no background services.

## Build the installer (on a Windows PC)

1. Install the **.NET 8 SDK**: https://dotnet.microsoft.com/download/dotnet/8.0
2. Install **Inno Setup 6**: https://jrsoftware.org/isdl.php
3. Double-click **`build.bat`**

You get `dist\WinMax-Setup-1.0.0.exe`. Run it like any normal installer.
The app is self-contained, so the target PC needs nothing else installed.
(No Inno Setup? `build.bat` still produces `publish\WinMax.exe`, which runs on its own.)

## What's inside

| Area | Options |
|---|---|
| Widgets | Clock, Date, Calendar, Weather, Notes, Reminders: **15 styles each (90 total)**. Drag to move, right-click for style, size, opacity, lock. |
| Live data | Weather from Open-Meteo (free, no key). Search any city once. Notes and reminders are saved locally; reminders pop a notification when due. |
| Looks | Dark, Light, Glass, Colourful. Accent presets or any hex colour. Corner radius, card opacity, 12/24-hour, °C/°F. |
| Taskbar | 9 looks: Default, Clear, Soft Blur, Frosted Glass, Tinted Glass, Accent Glass, Dark/Light/Accent Solid. Custom tint and strength. |
| Dock | 10 styles (floating glass, full-width, macOS magnify, island, neon, flat, colourful...). Any position, pick your own apps, auto-hide, can hide the Windows taskbar. |
| Start menu | Search launcher: centered, side panel or fullscreen. Hotkey, optional Windows key, power buttons, pin to dock. |
| Wallpaper | Video (4K capable, loops, optional sound), animated gradients, or a picture. Pauses for full-screen apps and on battery. |

Settings live in `%AppData%\WinMax\settings.json`. Closing the window keeps WinMax in the tray; right-click the tray icon to quit.

## Notes

- Windows does not allow apps to change *which* icons sit on its own taskbar. For full control of apps and layout, use the WinMax dock and tick "Hide the Windows taskbar".
- Taskbar transparency uses an undocumented Windows call that works on both 10 and 11, but a major Windows update can change it. "Windows Default" always restores the original.
- Video wallpaper plays whatever codecs your Windows has (MP4/H.264 is safest).
- The `preview/` pictures are concept renders, not screenshots.

## Test safely (no risk to your PC)

Run **`test-in-sandbox.bat`** after `build.bat`. It opens Windows Sandbox (a throwaway Windows 10/11 desktop built into Windows Pro/Enterprise/Education) and starts the installer inside it. Close the Sandbox window and everything is erased.
Turn it on once via "Turn Windows features on or off" > "Windows Sandbox", then restart.
Windows Home: use a VirtualBox/VMware VM with a Windows 10 or 11 install instead.
