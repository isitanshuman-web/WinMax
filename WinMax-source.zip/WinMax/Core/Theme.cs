using System;
using System.Collections.Generic;
using System.Windows.Media;

namespace WinMax.Core;

/// <summary>Central theme. Every widget, the dock and the launcher read from here.</summary>
public static class Theme
{
    public static readonly (string Name, string A, string B)[] Presets =
    {
        ("Violet",  "#B388FF", "#FF6EC7"),
        ("Rose",    "#FF6B8B", "#FFB36B"),
        ("Ocean",   "#4CC9F0", "#4361EE"),
        ("Emerald", "#34D399", "#10B981"),
        ("Sunset",  "#FF9A3C", "#FF4D6D"),
        ("Crimson", "#EF4444", "#B91C1C"),
        ("Gold",    "#FBBF24", "#F59E0B"),
        ("Mono",    "#E5E7EB", "#9CA3AF"),
    };

    public static event Action? Changed;

    public static string Mode => SettingsStore.S.ThemeMode;
    public static bool IsGlass => Mode == "Glass";
    public static bool IsLight => Mode == "Light";
    public static bool IsColorful => Mode == "Colorful";

    public static Color AccentC { get; private set; }
    public static Color Accent2C { get; private set; }
    public static Brush Accent { get; private set; } = Brushes.MediumPurple;
    public static Brush Accent2 { get; private set; } = Brushes.HotPink;
    public static Brush Text { get; private set; } = Brushes.White;
    public static Brush Sub { get; private set; } = Brushes.Gray;
    public static Brush CardBrush { get; private set; } = Brushes.Black;
    public static Brush Stroke { get; private set; } = Brushes.Gray;
    public static Color GlassTint { get; private set; }

    static Theme() => Refresh(false);

    public static Color Hex(string h)
    {
        try { return (Color)ColorConverter.ConvertFromString(h); }
        catch { return Colors.MediumPurple; }
    }

    public static SolidColorBrush Solid(Color c)
    {
        var b = new SolidColorBrush(c);
        b.Freeze();
        return b;
    }

    public static SolidColorBrush Solid(string hex) => Solid(Hex(hex));

    public static Color WithAlpha(Color c, double a) => Color.FromArgb((byte)Math.Clamp(a * 255, 0, 255), c.R, c.G, c.B);

    public static void Refresh(bool raise = true)
    {
        var s = SettingsStore.S;
        AccentC = Hex(s.Accent);
        Accent2C = Hex(s.Accent2);
        Accent = Solid(AccentC);
        Accent2 = Solid(Accent2C);
        double op = Math.Clamp(s.CardOpacity, 0.2, 1);

        switch (s.ThemeMode)
        {
            case "Light":
                Text = Solid("#1D1B26"); Sub = Solid("#6A667A");
                CardBrush = Solid(WithAlpha(Hex("#FFFFFF"), op));
                Stroke = Solid(Color.FromArgb(40, 0, 0, 0));
                GlassTint = Color.FromArgb(0xA0, 0xF5, 0xF3, 0xFA);
                break;
            case "Glass":
                Text = Solid("#FFFFFF"); Sub = Solid("#D4D0E4");
                CardBrush = Solid(Color.FromArgb(22, 255, 255, 255));
                Stroke = Solid(Color.FromArgb(55, 255, 255, 255));
                GlassTint = Color.FromArgb(0x70, 0x12, 0x10, 0x1C);
                break;
            case "Colorful":
                Text = Solid("#FFFFFF"); Sub = Solid(Color.FromArgb(220, 255, 255, 255));
                var g = new LinearGradientBrush(WithAlpha(AccentC, Math.Max(op, 0.55)), WithAlpha(Accent2C, Math.Max(op, 0.55)), 35);
                g.Freeze();
                CardBrush = g;
                Stroke = Solid(Color.FromArgb(70, 255, 255, 255));
                GlassTint = WithAlpha(AccentC, 0.45);
                break;
            default: // Dark
                Text = Solid("#F3F0FA"); Sub = Solid("#A9A3BA");
                CardBrush = Solid(WithAlpha(Hex("#1C1A24"), op));
                Stroke = Solid(Color.FromArgb(40, 255, 255, 255));
                GlassTint = Color.FromArgb(0xA0, 0x1C, 0x1A, 0x24);
                break;
        }
        if (raise) Changed?.Invoke();
    }

    // ---- Palette for WinMax's own settings window ----
    public static Color UiBg => IsLight ? Hex("#F4F2F8") : Hex("#14121A");
    public static Color UiPanel => IsLight ? Hex("#FFFFFF") : Hex("#1E1B27");
    public static Color UiPanel2 => IsLight ? Hex("#ECE9F3") : Hex("#272333");
    public static Color UiText => IsLight ? Hex("#1D1B26") : Hex("#F3F0FA");
    public static Color UiSub => IsLight ? Hex("#6A667A") : Hex("#A09AB2");
    public static Color UiStroke => IsLight ? Hex("#DAD6E6") : Hex("#332F40");
}
