using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows.Threading;

namespace WinMax.Core;

public class WidgetInstance
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Type { get; set; } = "Clock";
    public int Style { get; set; }
    public double X { get; set; }
    public double Y { get; set; }
    public double Scale { get; set; } = 1;
    public double Opacity { get; set; } = 1;
    public bool Locked { get; set; }
}

public class PinnedApp
{
    public string Name { get; set; } = "";
    public string Path { get; set; } = "";
}

public class ReminderItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Text { get; set; } = "";
    public DateTime? Due { get; set; }
    public bool Done { get; set; }
    public bool Notified { get; set; }
    public DateTime Created { get; set; } = DateTime.Now;
}

public class AppSettings
{
    // Look and feel
    public string ThemeMode { get; set; } = "Dark";        // Dark | Light | Glass | Colorful
    public string Accent { get; set; } = "#B388FF";
    public string Accent2 { get; set; } = "#FF6EC7";
    public double CornerRadius { get; set; } = 18;
    public double CardOpacity { get; set; } = 0.78;
    public string GlassType { get; set; } = "Blur";         // Blur (fast, Win10 friendly) | Acrylic
    public bool Use24Hour { get; set; }
    public bool Fahrenheit { get; set; }
    public bool WidgetsOnDesktopLayer { get; set; } = true;
    public bool WidgetsVisible { get; set; } = true;

    // General
    public bool StartWithWindows { get; set; }
    public bool FirstRunDone { get; set; }

    // Location (Open-Meteo, no API key)
    public string LocationName { get; set; } = "";
    public double Lat { get; set; }
    public double Lon { get; set; }
    [JsonIgnore] public bool HasLocation => !string.IsNullOrWhiteSpace(LocationName);

    // Widgets + data
    public List<WidgetInstance> Widgets { get; set; } = new();
    public Dictionary<string, string> Notes { get; set; } = new();
    public List<ReminderItem> Reminders { get; set; } = new();

    // Taskbar styling
    public string TaskbarMode { get; set; } = "Default";
    public string TaskbarTint { get; set; } = "#000000";
    public double TaskbarOpacity { get; set; } = 0.5;

    // Dock
    public bool DockEnabled { get; set; }
    public int DockStyle { get; set; }
    public string DockPosition { get; set; } = "Bottom";    // Bottom | Top | Left | Right
    public double DockIconSize { get; set; } = 44;
    public bool DockAutoHide { get; set; }
    public bool HideSystemTaskbar { get; set; }
    public List<PinnedApp> DockApps { get; set; } = new();

    // Launcher / start menu
    public bool LauncherEnabled { get; set; } = true;
    public string LauncherLayout { get; set; } = "Centered"; // Centered | Side | Fullscreen
    public int HotkeyIndex { get; set; }
    public bool WinKeyOpensLauncher { get; set; }

    // Wallpaper
    public string WallpaperKind { get; set; } = "None";      // None | Image | Video | Aurora
    public string WallpaperPath { get; set; } = "";
    public int AuroraPreset { get; set; }
    public bool WallpaperMute { get; set; } = true;
    public double WallpaperVolume { get; set; } = 0.3;
    public bool PauseWhenCovered { get; set; } = true;
    public bool PauseOnBattery { get; set; } = true;
}

public static class SettingsStore
{
    public static AppSettings S { get; private set; } = new();
    public static string Dir { get; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "WinMax");
    static string FilePath => Path.Combine(Dir, "settings.json");
    static readonly JsonSerializerOptions Opt = new() { WriteIndented = true };
    static DispatcherTimer? _debounce;

    public static void Load()
    {
        try
        {
            Directory.CreateDirectory(Dir);
            if (File.Exists(FilePath))
                S = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath), Opt) ?? new AppSettings();
        }
        catch (Exception ex) { Log.Write(ex); S = new AppSettings(); }
    }

    public static void Save()
    {
        try
        {
            Directory.CreateDirectory(Dir);
            string tmp = FilePath + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(S, Opt));
            File.Move(tmp, FilePath, true);
        }
        catch (Exception ex) { Log.Write(ex); }
    }

    /// <summary>Debounced save for frequent changes (typing in notes, dragging widgets).</summary>
    public static void SaveSoon()
    {
        _debounce ??= new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(600) };
        _debounce.Tick -= OnDebounce;
        _debounce.Tick += OnDebounce;
        _debounce.Stop();
        _debounce.Start();
    }

    static void OnDebounce(object? s, EventArgs e)
    {
        _debounce?.Stop();
        Save();
    }
}
