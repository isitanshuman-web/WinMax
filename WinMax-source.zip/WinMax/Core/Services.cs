using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace WinMax.Core;

public static class Log
{
    public static void Write(Exception ex) => Write(ex.ToString());
    public static void Write(string msg)
    {
        try
        {
            Directory.CreateDirectory(SettingsStore.Dir);
            File.AppendAllText(Path.Combine(SettingsStore.Dir, "log.txt"), $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {msg}{Environment.NewLine}");
        }
        catch { /* never crash because of logging */ }
    }
}

public static class AppEvents
{
    public static event Action? RemindersChanged;
    public static void RaiseRemindersChanged() => RemindersChanged?.Invoke();
}

// ---------------------------------------------------------------- Reminders

public static class ReminderStore
{
    static List<ReminderItem> All => SettingsStore.S.Reminders;

    public static List<ReminderItem> Active() =>
        All.Where(r => !r.Done).OrderBy(r => r.Due ?? DateTime.MaxValue).ThenBy(r => r.Created).ToList();

    public static int ActiveCount => All.Count(r => !r.Done);
    public static int DoneCount => All.Count(r => r.Done);

    public static void Add(string text, DateTime? due)
    {
        if (string.IsNullOrWhiteSpace(text)) return;
        All.Add(new ReminderItem { Text = text.Trim(), Due = due });
        Changed();
    }

    public static void Toggle(string id)
    {
        var r = All.FirstOrDefault(x => x.Id == id);
        if (r == null) return;
        r.Done = !r.Done;
        Changed();
    }

    public static void Remove(string id)
    {
        All.RemoveAll(x => x.Id == id);
        Changed();
    }

    public static void ClearDone()
    {
        All.RemoveAll(x => x.Done);
        Changed();
    }

    static void Changed()
    {
        SettingsStore.Save();
        AppEvents.RaiseRemindersChanged();
    }

    /// <summary>Called by a timer. Returns reminders that just became due.</summary>
    public static List<ReminderItem> TakeDue()
    {
        var due = All.Where(r => !r.Done && !r.Notified && r.Due.HasValue && r.Due.Value <= DateTime.Now).ToList();
        if (due.Count > 0)
        {
            foreach (var r in due) r.Notified = true;
            SettingsStore.Save();
        }
        return due;
    }
}

// ---------------------------------------------------------------- Weather

public class DayForecast
{
    public DateTime Date;
    public double Max, Min;
    public int Code;
}

public class WeatherData
{
    public string City = "";
    public double Temp, Feels, Wind;
    public int Humidity, Code;
    public bool IsDay = true;
    public DateTime Sunrise, Sunset, Updated;
    public List<DayForecast> Days = new();

    public static WeatherData Sample
    {
        get
        {
            var d = DateTime.Today;
            return new WeatherData
            {
                City = "Your City", Temp = 26, Feels = 28, Wind = 12, Humidity = 54, Code = 2, IsDay = true,
                Sunrise = d.AddHours(6.2), Sunset = d.AddHours(18.4), Updated = DateTime.Now,
                Days = Enumerable.Range(0, 5).Select(i => new DayForecast
                {
                    Date = d.AddDays(i), Max = 29 - i, Min = 19 + (i % 2), Code = new[] { 2, 1, 61, 3, 0 }[i]
                }).ToList()
            };
        }
    }

    public static string Describe(int code) => code switch
    {
        0 => "Clear sky", 1 => "Mainly clear", 2 => "Partly cloudy", 3 => "Overcast",
        45 or 48 => "Foggy",
        >= 51 and <= 57 => "Drizzle",
        >= 61 and <= 67 => "Rain",
        >= 71 and <= 77 => "Snow",
        >= 80 and <= 82 => "Rain showers",
        85 or 86 => "Snow showers",
        95 => "Thunderstorm",
        96 or 99 => "Thunderstorm, hail",
        _ => "Unknown"
    };

    public static string Icon(int code, bool day = true) => code switch
    {
        0 => day ? "☀️" : "🌙",
        1 => day ? "🌤️" : "🌙",
        2 => "⛅",
        3 => "☁️",
        45 or 48 => "🌫️",
        >= 51 and <= 57 => "🌦️",
        >= 61 and <= 67 => "🌧️",
        >= 71 and <= 77 => "❄️",
        >= 80 and <= 82 => "🌧️",
        85 or 86 => "🌨️",
        >= 95 => "⛈️",
        _ => "🌡️"
    };
}

public class GeoResult
{
    public string Name = "", Region = "", Country = "";
    public double Lat, Lon;
    public string Display => string.Join(", ", new[] { Name, Region, Country }.Where(x => !string.IsNullOrWhiteSpace(x)));
}

public static class WeatherService
{
    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(15) };
    public static WeatherData? Current { get; private set; }
    public static string? LastError { get; private set; }
    public static event Action? Updated;

    static WeatherService() => Http.DefaultRequestHeaders.UserAgent.ParseAdd("WinMax/1.0");

    public static async Task RefreshAsync()
    {
        var s = SettingsStore.S;
        if (!s.HasLocation) { Current = null; Updated?.Invoke(); return; }
        try
        {
            string url = string.Create(CultureInfo.InvariantCulture,
                $"https://api.open-meteo.com/v1/forecast?latitude={s.Lat}&longitude={s.Lon}" +
                $"&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,is_day" +
                $"&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=auto&forecast_days=5");
            using var doc = JsonDocument.Parse(await Http.GetStringAsync(url));
            var root = doc.RootElement;
            var cur = root.GetProperty("current");
            var daily = root.GetProperty("daily");
            var w = new WeatherData
            {
                City = s.LocationName.Split(',')[0].Trim(),
                Temp = cur.GetProperty("temperature_2m").GetDouble(),
                Feels = cur.GetProperty("apparent_temperature").GetDouble(),
                Humidity = (int)Math.Round(cur.GetProperty("relative_humidity_2m").GetDouble()),
                Wind = cur.GetProperty("wind_speed_10m").GetDouble(),
                Code = cur.GetProperty("weather_code").GetInt32(),
                IsDay = cur.GetProperty("is_day").GetInt32() == 1,
                Updated = DateTime.Now
            };
            var times = daily.GetProperty("time").EnumerateArray().Select(x => x.GetString()!).ToList();
            var codes = daily.GetProperty("weather_code").EnumerateArray().Select(x => x.GetInt32()).ToList();
            var max = daily.GetProperty("temperature_2m_max").EnumerateArray().Select(x => x.GetDouble()).ToList();
            var min = daily.GetProperty("temperature_2m_min").EnumerateArray().Select(x => x.GetDouble()).ToList();
            var rise = daily.GetProperty("sunrise").EnumerateArray().Select(x => x.GetString()!).ToList();
            var set = daily.GetProperty("sunset").EnumerateArray().Select(x => x.GetString()!).ToList();
            for (int i = 0; i < times.Count; i++)
                w.Days.Add(new DayForecast { Date = DateTime.Parse(times[i], CultureInfo.InvariantCulture), Code = codes[i], Max = max[i], Min = min[i] });
            if (rise.Count > 0) w.Sunrise = DateTime.Parse(rise[0], CultureInfo.InvariantCulture);
            if (set.Count > 0) w.Sunset = DateTime.Parse(set[0], CultureInfo.InvariantCulture);
            Current = w;
            LastError = null;
        }
        catch (Exception ex)
        {
            LastError = ex.Message;
            Log.Write(ex);
        }
        Updated?.Invoke();
    }

    public static async Task<List<GeoResult>> SearchAsync(string query)
    {
        var list = new List<GeoResult>();
        if (string.IsNullOrWhiteSpace(query)) return list;
        try
        {
            string url = "https://geocoding-api.open-meteo.com/v1/search?count=8&language=en&format=json&name=" + Uri.EscapeDataString(query.Trim());
            using var doc = JsonDocument.Parse(await Http.GetStringAsync(url));
            if (!doc.RootElement.TryGetProperty("results", out var results)) return list;
            foreach (var r in results.EnumerateArray())
            {
                list.Add(new GeoResult
                {
                    Name = r.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "",
                    Region = r.TryGetProperty("admin1", out var a) ? a.GetString() ?? "" : "",
                    Country = r.TryGetProperty("country", out var c) ? c.GetString() ?? "" : "",
                    Lat = r.GetProperty("latitude").GetDouble(),
                    Lon = r.GetProperty("longitude").GetDouble()
                });
            }
        }
        catch (Exception ex) { Log.Write(ex); }
        return list;
    }

    /// <summary>Approximate location from the public IP address (optional convenience).</summary>
    public static async Task<GeoResult?> DetectByIpAsync()
    {
        try
        {
            using var doc = JsonDocument.Parse(await Http.GetStringAsync("https://ipwho.is/"));
            var r = doc.RootElement;
            if (r.TryGetProperty("success", out var ok) && ok.ValueKind == JsonValueKind.False) return null;
            return new GeoResult
            {
                Name = r.GetProperty("city").GetString() ?? "",
                Region = r.TryGetProperty("region", out var rg) ? rg.GetString() ?? "" : "",
                Country = r.TryGetProperty("country", out var c) ? c.GetString() ?? "" : "",
                Lat = r.GetProperty("latitude").GetDouble(),
                Lon = r.GetProperty("longitude").GetDouble()
            };
        }
        catch (Exception ex) { Log.Write(ex); return null; }
    }
}

// ---------------------------------------------------------------- System helpers

public static class StartupReg
{
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    const string Name = "WinMax";

    public static void Set(bool enabled)
    {
        try
        {
            using var k = Registry.CurrentUser.OpenSubKey(RunKey, true) ?? Registry.CurrentUser.CreateSubKey(RunKey);
            if (enabled) k.SetValue(Name, $"\"{Environment.ProcessPath}\" --startup");
            else k.DeleteValue(Name, false);
        }
        catch (Exception ex) { Log.Write(ex); }
    }

    public static bool IsSet()
    {
        try { using var k = Registry.CurrentUser.OpenSubKey(RunKey); return k?.GetValue(Name) != null; }
        catch { return false; }
    }
}

public static class PowerActions
{
    public static void Lock() => Native.LockWorkStation();
    public static void Sleep() => Native.SetSuspendState(false, true, true);
    public static void Restart() => Run("shutdown", "/r /t 0");
    public static void Shutdown() => Run("shutdown", "/s /t 0");
    public static void SignOut() => Run("shutdown", "/l");
    static void Run(string exe, string args)
    {
        try { Process.Start(new ProcessStartInfo(exe, args) { CreateNoWindow = true, UseShellExecute = false }); }
        catch (Exception ex) { Log.Write(ex); }
    }
}
