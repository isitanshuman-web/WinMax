using System;
using System.Linq;
using System.Threading;
using System.Windows;
using WinMax.Core;
using WinMax.Shell;
using WinMax.Widgets;

namespace WinMax;

public static class Program
{
    [STAThread]
    public static void Main(string[] args)
    {
        // "WinMax.exe --quit" is used by the installer/uninstaller to close a running copy cleanly.
        if (args.Contains("--quit"))
        {
            try { using var ev = EventWaitHandle.OpenExisting("WinMax.Quit.v1"); ev.Set(); } catch { /* not running */ }
            return;
        }

        using var mutex = new Mutex(true, "WinMax.SingleInstance.v1", out bool first);
        if (!first) return;   // already running (tray icon is the way back in)

        var app = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };

        var quit = new EventWaitHandle(false, EventResetMode.AutoReset, "WinMax.Quit.v1");
        new Thread(() =>
        {
            quit.WaitOne();
            app.Dispatcher.BeginInvoke(new Action(Tray.ExitApp));
        }) { IsBackground = true }.Start();

        app.DispatcherUnhandledException += (_, e) => { Log.Write(e.Exception); e.Handled = true; };
        AppDomain.CurrentDomain.UnhandledException += (_, e) => Log.Write(e.ExceptionObject?.ToString() ?? "unknown error");

        bool startup = args.Contains("--startup");
        app.Dispatcher.BeginInvoke(new Action(() => Init(startup)));
        app.Run();
    }

    static void Init(bool startup)
    {
        SettingsStore.Load();
        Theme.Refresh(false);

        Tray.Init();
        WidgetManager.Start();
        TaskbarStyler.Apply();
        DockManager.Apply();
        Hotkeys.Apply();
        WallpaperEngine.Apply();
        Launcher.Reload();

        // Show the control panel on a manual launch; stay quietly in the tray at Windows start-up.
        if (!startup) UI.MainWindow.ShowMain();
    }
}
