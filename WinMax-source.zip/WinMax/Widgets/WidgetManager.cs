using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using WinMax.Core;

namespace WinMax.Widgets;

/// <summary>Owns every widget window and one shared timer (lightweight: one tick per second, no per-widget timers).</summary>
public static class WidgetManager
{
    static readonly List<WidgetWindow> Windows = new();
    static DispatcherTimer? _tick;
    static DispatcherTimer? _weather;
    static DispatcherTimer? _reminders;
    static bool _started;

    public static IReadOnlyList<WidgetInstance> Instances => SettingsStore.S.Widgets;

    public static void Start()
    {
        if (_started) return;
        _started = true;

        if (SettingsStore.S.Widgets.Count == 0 && !SettingsStore.S.FirstRunDone) CreateDefaultLayout();

        RebuildAll();

        _tick = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _tick.Tick += (_, _) => OnTick();
        _tick.Start();

        _weather = new DispatcherTimer { Interval = TimeSpan.FromMinutes(20) };
        _weather.Tick += async (_, _) => await WeatherService.RefreshAsync();
        _weather.Start();
        _ = WeatherService.RefreshAsync();

        _reminders = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
        _reminders.Tick += (_, _) => CheckReminders();
        _reminders.Start();

        WeatherService.Updated += () => RefreshType("Weather");
        AppEvents.RemindersChanged += () => { RefreshType("Reminders"); RefreshType("Calendar"); };
        Theme.Changed += RebuildAll;
    }

    static void CreateDefaultLayout()
    {
        var wa = SystemParameters.WorkArea;
        var list = SettingsStore.S.Widgets;
        list.Add(new WidgetInstance { Type = "Date", Style = 0, X = wa.Left + wa.Width / 2 - 190, Y = wa.Top + 70 });
        list.Add(new WidgetInstance { Type = "Clock", Style = 0, X = wa.Left + 30, Y = wa.Bottom - 190 });
        list.Add(new WidgetInstance { Type = "Calendar", Style = 0, X = wa.Right - 270, Y = wa.Top + 60 });
        list.Add(new WidgetInstance { Type = "Notes", Style = 0, X = wa.Right - 270, Y = wa.Top + 400 });
        list.Add(new WidgetInstance { Type = "Weather", Style = 3, X = wa.Left + 30, Y = wa.Bottom - 70 });
        SettingsStore.S.FirstRunDone = true;
        SettingsStore.Save();
    }

    public static void RebuildAll()
    {
        foreach (var w in Windows) w.Close();
        Windows.Clear();
        foreach (var inst in SettingsStore.S.Widgets) Create(inst);
        ApplyVisibility();
    }

    static WidgetWindow Create(WidgetInstance inst)
    {
        var w = new WidgetWindow(inst);
        Windows.Add(w);
        w.Show();
        return w;
    }

    public static WidgetInstance Add(string type, int style)
    {
        var wa = SystemParameters.WorkArea;
        int n = SettingsStore.S.Widgets.Count;
        var inst = new WidgetInstance
        {
            Type = type, Style = style,
            X = wa.Left + wa.Width / 2 - 100 + (n % 6) * 28,
            Y = wa.Top + wa.Height / 2 - 100 + (n % 6) * 28
        };
        SettingsStore.S.Widgets.Add(inst);
        SettingsStore.Save();
        var win = Create(inst);
        if (!SettingsStore.S.WidgetsVisible) win.Hide();
        return inst;
    }

    public static void Remove(string id)
    {
        var w = Windows.FirstOrDefault(x => x.Inst.Id == id);
        if (w != null) { w.Close(); Windows.Remove(w); }
        SettingsStore.S.Widgets.RemoveAll(x => x.Id == id);
        SettingsStore.S.Notes.Remove(id);
        SettingsStore.Save();
    }

    /// <summary>Re-creates one window (needed when the style changes between glass and non-glass).</summary>
    public static void Recreate(WidgetInstance inst)
    {
        var old = Windows.FirstOrDefault(x => x.Inst.Id == inst.Id);
        if (old != null) { old.Close(); Windows.Remove(old); }
        var w = Create(inst);
        if (!SettingsStore.S.WidgetsVisible) w.Hide();
    }

    public static void ChangeStyle(WidgetInstance inst, int style)
    {
        inst.Style = style;
        SettingsStore.Save();
        Recreate(inst);
    }

    public static void ResetPositions()
    {
        SettingsStore.S.Widgets.Clear();
        SettingsStore.S.FirstRunDone = false;
        CreateDefaultLayout();
        RebuildAll();
    }

    public static void SetVisible(bool visible)
    {
        SettingsStore.S.WidgetsVisible = visible;
        SettingsStore.Save();
        ApplyVisibility();
    }

    static void ApplyVisibility()
    {
        foreach (var w in Windows)
        {
            if (SettingsStore.S.WidgetsVisible) { if (!w.IsVisible) w.Show(); }
            else w.Hide();
        }
    }

    public static void RefreshType(string type)
    {
        foreach (var w in Windows.Where(x => x.Inst.Type == type)) w.Render();
    }

    static void OnTick()
    {
        if (!SettingsStore.S.WidgetsVisible) return;
        bool minute = DateTime.Now.Second == 0;
        foreach (var w in Windows)
        {
            if (w.Inst.Type == "Notes" || w.IsKeyboardFocusWithin) continue;
            if (w.Def.Ticks || (minute && w.Inst.Type is "Clock" or "Date" or "Calendar" or "Reminders")) w.Render();
        }
    }

    static void CheckReminders()
    {
        var due = ReminderStore.TakeDue();
        foreach (var r in due) Shell.Tray.Notify("Reminder", r.Text);
        if (due.Count > 0) AppEvents.RaiseRemindersChanged();
    }

    public static void ApplyLayerSetting()
    {
        RebuildAll();
    }
}
