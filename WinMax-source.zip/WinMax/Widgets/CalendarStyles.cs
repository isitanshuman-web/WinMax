using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using WinMax.Core;

namespace WinMax.Widgets;

public static class CalendarStyles
{
    record MonthOpts(bool WeekNums = false, bool Monday = true, double Cell = 26, double Font = 12,
                     string Today = "circle", bool Weekdays = true, bool Title = true);

    static string DayName(int dow, int len)
    {
        string n = CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedDayNames[dow % 7];
        return n.Substring(0, Math.Min(len, n.Length)).ToUpper();
    }

    static UIElement Month(Ctx c, DateTime month, MonthOpts o)
    {
        var first = new DateTime(month.Year, month.Month, 1);
        int offset = ((int)first.DayOfWeek - (o.Monday ? 1 : 0) + 7) % 7;
        int days = DateTime.DaysInMonth(month.Year, month.Month);
        int rows = (int)Math.Ceiling((offset + days) / 7.0);
        int cols = o.WeekNums ? 8 : 7;

        var grid = new Grid();
        for (int i = 0; i < cols; i++) grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(o.Cell) });
        int totalRows = rows + (o.Weekdays ? 1 : 0);
        for (int i = 0; i < totalRows; i++) grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(o.Cell) });

        int colShift = o.WeekNums ? 1 : 0;
        if (o.Weekdays)
            for (int i = 0; i < 7; i++)
            {
                int dow = (i + (o.Monday ? 1 : 0)) % 7;
                var t = V.T(DayName(dow, 1), o.Font - 1, dow == 0 ? Theme.Accent : Theme.Sub, V.Semi);
                t.HorizontalAlignment = HorizontalAlignment.Center; t.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(t, i + colShift); Grid.SetRow(t, 0);
                grid.Children.Add(t);
            }

        for (int r = 0; r < rows; r++)
        {
            if (o.WeekNums)
            {
                var anchor = first.AddDays(r * 7 - offset + 3);
                var wn = V.T(ISOWeek.GetWeekOfYear(anchor).ToString(), o.Font - 2, V.A(Theme.Sub, 0.7));
                wn.HorizontalAlignment = HorizontalAlignment.Center; wn.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(wn, 0); Grid.SetRow(wn, r + (o.Weekdays ? 1 : 0));
                grid.Children.Add(wn);
            }
            for (int col = 0; col < 7; col++)
            {
                int d = r * 7 + col - offset + 1;
                if (d < 1 || d > days) continue;
                bool today = month.Year == c.Now.Year && month.Month == c.Now.Month && d == c.Now.Day;
                var cell = new Grid();
                Brush fg = Theme.Text;
                if (today)
                {
                    switch (o.Today)
                    {
                        case "circle":
                            cell.Children.Add(new Ellipse { Width = o.Cell - 4, Height = o.Cell - 4, Fill = Theme.Accent });
                            fg = Brushes.White; break;
                        case "square":
                            cell.Children.Add(new Border { Width = o.Cell - 4, Height = o.Cell - 4, CornerRadius = new CornerRadius(6), Background = Theme.Accent });
                            fg = Brushes.White; break;
                        case "underline":
                            cell.Children.Add(new Rectangle { Height = 3, Width = o.Cell - 8, Fill = Theme.Accent, VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(0, 0, 0, 2) });
                            break;
                        case "dot":
                            cell.Children.Add(V.Dot(5, Theme.Accent).M(0, 0, 0, 1));
                            ((FrameworkElement)cell.Children[0]).VerticalAlignment = VerticalAlignment.Bottom;
                            break;
                        default: fg = Theme.Accent; break;
                    }
                }
                var num = V.T(d.ToString(), o.Font, fg, today ? V.Semi : V.Reg, today ? FontWeights.SemiBold : FontWeights.Normal);
                num.HorizontalAlignment = HorizontalAlignment.Center; num.VerticalAlignment = VerticalAlignment.Center;
                cell.Children.Add(num);
                Grid.SetColumn(cell, col + colShift); Grid.SetRow(cell, r + (o.Weekdays ? 1 : 0));
                grid.Children.Add(cell);
            }
        }

        if (!o.Title) return grid;
        var title = V.HS(V.T(month.ToString("MMMM").ToUpper(), o.Font, Theme.Accent, V.Semi), V.T(" " + month.Year, o.Font, Theme.Sub));
        title.Margin = new Thickness(4, 0, 0, 4);
        return V.VS(title, grid);
    }

    static DateTime WeekStart(DateTime d)
    {
        int diff = ((int)d.DayOfWeek + 6) % 7;
        return d.Date.AddDays(-diff);
    }

    static string ShortDay(DateTime d) => d.ToString("ddd").ToUpper();

    public static readonly List<StyleDef> All = new()
    {
        // 1
        new("Classic Circle", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts()), 14)),
        // 2
        new("Compact", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts(Cell: 20, Font: 10)), 10)),
        // 3
        new("Week Numbers", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts(WeekNums: true)), 14)),
        // 4
        new("Large", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts(Cell: 38, Font: 15)), 18)),
        // 5
        new("Square Highlight", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts(Today: "square")), 14)),
        // 6
        new("Underline", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts(Today: "underline")), 14)),
        // 7
        new("Dot Marker", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts(Today: "dot")), 14)),
        // 8
        new("Sunday Start", false, true, c => V.Pad(Month(c, c.Now, new MonthOpts(Monday: false)), 14)),
        // 9
        new("Banner Header", false, false, c =>
        {
            var banner = new Border
            {
                Background = Theme.Accent, CornerRadius = new CornerRadius(14, 14, 0, 0), Padding = new Thickness(16, 10, 16, 10),
                Child = V.HS(V.T(c.Now.ToString("MMMM"), 20, Brushes.White, V.Semi), V.T("  " + c.Now.Year, 20, new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)), V.Light))
            };
            var body = new Border { Background = Theme.CardBrush, CornerRadius = new CornerRadius(0, 0, 14, 14), Padding = new Thickness(12), Child = Month(c, c.Now, new MonthOpts(Title: false)) };
            return V.VS(banner, body);
        }),
        // 10
        new("Week Strip", false, true, c =>
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            var start = WeekStart(c.Now);
            for (int i = 0; i < 7; i++)
            {
                var d = start.AddDays(i);
                bool today = d.Date == c.Now.Date;
                var col = V.VS(V.T(ShortDay(d), 11, today ? Brushes.White : Theme.Sub, V.Semi).Center(),
                               V.T(d.Day.ToString(), 20, today ? Brushes.White : Theme.Text, V.Light).Center().M(0, 2, 0, 0));
                row.Children.Add(new Border { Width = 46, Padding = new Thickness(0, 8, 0, 8), Margin = new Thickness(2), CornerRadius = new CornerRadius(12), Background = today ? Theme.Accent : Brushes.Transparent, Child = col });
            }
            return V.Pad(row, 8);
        }),
        // 11
        new("Week List", false, true, c =>
        {
            var sp = new StackPanel();
            var start = WeekStart(c.Now);
            for (int i = 0; i < 7; i++)
            {
                var d = start.AddDays(i);
                bool today = d.Date == c.Now.Date;
                var row = new Grid { Width = 190 };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
                row.ColumnDefinitions.Add(new ColumnDefinition());
                var name = V.T(ShortDay(d), 12, today ? Brushes.White : Theme.Sub, V.Semi);
                var num = V.T(d.ToString("d MMM"), 14, today ? Brushes.White : Theme.Text);
                Grid.SetColumn(num, 1);
                row.Children.Add(name); row.Children.Add(num);
                sp.Children.Add(new Border { Padding = new Thickness(12, 5, 12, 5), CornerRadius = new CornerRadius(8), Background = today ? Theme.Accent : Brushes.Transparent, Child = row });
            }
            return V.Pad(sp, 8);
        }),
        // 12
        new("Two Months", false, true, c => V.Pad(V.HS(
            Month(c, c.Now, new MonthOpts(Cell: 24, Font: 11)),
            V.Line(1, 160, Theme.Stroke).M(14, 0, 14, 0),
            Month(c, new DateTime(c.Now.Year, c.Now.Month, 1).AddMonths(1), new MonthOpts(Cell: 24, Font: 11))), 14)),
        // 13
        new("Agenda", false, true, c =>
        {
            var sp = new StackPanel { Width = 230 };
            sp.Children.Add(V.HS(V.T(c.Now.Day.ToString(), 44, Theme.Text, V.Light),
                V.VS(V.T(c.Now.ToString("dddd"), 15, Theme.Text, V.Semi), V.T(c.Now.ToString("MMMM yyyy"), 12, Theme.Sub)).M(10, 6, 0, 0)));
            var reminders = SettingsStore.S.Reminders.Where(r => !r.Done && r.Due.HasValue).ToList();
            for (int i = 1; i <= 6; i++)
            {
                var d = c.Now.Date.AddDays(i);
                var items = reminders.Where(r => r.Due!.Value.Date == d).ToList();
                var line = V.HS(V.T(d.ToString("ddd d"), 12, Theme.Sub, V.Semi).M(0, 0, 10, 0),
                                items.Count > 0 ? V.T("● " + items[0].Text + (items.Count > 1 ? $" +{items.Count - 1}" : ""), 12, Theme.Accent)
                                                : V.T("—", 12, V.A(Theme.Sub, 0.5)));
                line.Margin = new Thickness(0, 5, 0, 0);
                sp.Children.Add(line);
            }
            return V.Pad(sp, 18, 14, 18, 14);
        }),
        // 14
        new("Month Progress", false, true, c =>
        {
            int dim = DateTime.DaysInMonth(c.Now.Year, c.Now.Month);
            var track = new Grid { Width = 210, Height = 8, Margin = new Thickness(0, 10, 0, 0) };
            track.Children.Add(new Border { Background = Theme.Stroke, CornerRadius = new CornerRadius(4) });
            track.Children.Add(new Border { Background = Theme.Accent, CornerRadius = new CornerRadius(4), HorizontalAlignment = HorizontalAlignment.Left, Width = 210.0 * c.Now.Day / dim });
            return V.Pad(V.VS(V.T(c.Now.ToString("MMMM yyyy"), 22, Theme.Text, V.Light), track,
                V.T($"Day {c.Now.Day} of {dim}  ·  {dim - c.Now.Day} left", 12, Theme.Sub).M(0, 6, 0, 0)), 20, 14, 20, 14);
        }),
        // 15
        new("Minimal Numbers", false, false, c => Month(c, c.Now, new MonthOpts(Cell: 30, Font: 13, Today: "bold", Weekdays: false, Title: false)).Shadow()),
    };
}
