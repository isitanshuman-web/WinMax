using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Threading;
using WinMax.Core;

namespace WinMax.Widgets;

public static class Catalog
{
    public static readonly string[] Types = { "Clock", "Date", "Calendar", "Weather", "Notes", "Reminders" };
    public static readonly Dictionary<string, string> Icons = new()
    {
        ["Clock"] = "🕒", ["Date"] = "📅", ["Calendar"] = "🗓️", ["Weather"] = "⛅", ["Notes"] = "📝", ["Reminders"] = "✅"
    };

    public static List<StyleDef> Styles(string type) => type switch
    {
        "Clock" => ClockStyles.All,
        "Date" => DateStyles.All,
        "Calendar" => CalendarStyles.All,
        "Weather" => WeatherStyles.All,
        "Notes" => NotesStyles.All,
        "Reminders" => RemindersStyles.All,
        _ => ClockStyles.All
    };

    public static StyleDef Get(string type, int index)
    {
        var l = Styles(type);
        return l[Math.Clamp(index, 0, l.Count - 1)];
    }
}

/// <summary>One desktop widget. Draggable, right-click menu, optional blur-behind glass.</summary>
public class WidgetWindow : Window
{
    public WidgetInstance Inst { get; }
    public StyleDef Def { get; private set; }
    readonly bool _glass;
    readonly Border _host;
    DispatcherTimer? _saveTimer;
    IntPtr _hwnd;

    public WidgetWindow(WidgetInstance inst)
    {
        Inst = inst;
        Def = Catalog.Get(inst.Type, inst.Style);
        _glass = Theme.IsGlass && Def.Card;

        WindowStyle = WindowStyle.None;
        ResizeMode = ResizeMode.NoResize;
        ShowInTaskbar = false;
        ShowActivated = false;
        SizeToContent = SizeToContent.WidthAndHeight;
        WindowStartupLocation = WindowStartupLocation.Manual;
        AllowsTransparency = !_glass;
        Background = Brushes.Transparent;
        Topmost = !SettingsStore.S.WidgetsOnDesktopLayer;
        Left = inst.X; Top = inst.Y;
        Title = "WinMax Widget";

        _host = new Border
        {
            Background = Def.Card ? Theme.CardBrush : new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)),
            CornerRadius = _glass ? new CornerRadius(0) : new CornerRadius(Def.Card ? SettingsStore.S.CornerRadius : 0),
            BorderBrush = Def.Card ? Theme.Stroke : null,
            BorderThickness = Def.Card ? new Thickness(1) : new Thickness(0),
            SnapsToDevicePixels = true
        };
        Content = _host;
        Render();

        MouseLeftButtonDown += OnMouseDown;
        LocationChanged += OnLocationChanged;
        Activated += (_, _) => { if (SettingsStore.S.WidgetsOnDesktopLayer && _hwnd != IntPtr.Zero) Native.SendToBottom(_hwnd); };
        StateChanged += (_, _) =>
        {
            // "Show desktop" minimises windows; keep widgets visible on the desktop layer.
            if (WindowState == WindowState.Minimized) { WindowState = WindowState.Normal; if (_hwnd != IntPtr.Zero) Native.SendToBottom(_hwnd); }
        };
        BuildMenu();
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        _hwnd = new WindowInteropHelper(this).Handle;
        Native.HideFromAltTab(_hwnd);

        if (_glass)
        {
            var src = HwndSource.FromHwnd(_hwnd);
            if (src?.CompositionTarget != null) src.CompositionTarget.BackgroundColor = Colors.Transparent;
            var m = new Native.MARGINS { L = -1, R = -1, T = -1, B = -1 };
            Native.DwmExtendFrameIntoClientArea(_hwnd, ref m);
            Native.SetAccent(_hwnd, SettingsStore.S.GlassType == "Acrylic" ? Native.ACCENT_ACRYLIC : Native.ACCENT_BLUR, Theme.GlassTint);
            if (Native.IsWindows11) Native.SetRoundedCorners(_hwnd, true);
            else SizeChanged += (_, _) => RoundForWin10();
        }
        if (SettingsStore.S.WidgetsOnDesktopLayer) Native.SendToBottom(_hwnd);
    }

    void RoundForWin10()
    {
        var dpi = VisualTreeHelper.GetDpi(this);
        int w = (int)(ActualWidth * dpi.DpiScaleX), h = (int)(ActualHeight * dpi.DpiScaleY);
        Native.ApplyRegionRounding(_hwnd, w, h, (int)(Math.Min(SettingsStore.S.CornerRadius, 14) * dpi.DpiScaleX));
    }

    public void Render()
    {
        var ctx = new Ctx { Now = DateTime.Now, Inst = Inst, Refresh = Render };
        UIElement el;
        try { el = Def.Build(ctx); }
        catch (Exception ex) { Log.Write(ex); el = V.T("widget error", 12, Brushes.IndianRed); }
        _host.Child = new Border
        {
            Child = el,
            LayoutTransform = new ScaleTransform(Inst.Scale, Inst.Scale)
        };
        _host.Opacity = Inst.Opacity;
    }

    static bool IsInteractive(DependencyObject? d)
    {
        while (d != null)
        {
            if (d is TextBoxBase || d is ButtonBase || d is Slider) return true;
            d = d is Visual || d is System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
        }
        return false;
    }

    void OnMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (Inst.Locked) return;
        bool alt = (Keyboard.Modifiers & ModifierKeys.Alt) != 0;
        if (!alt && IsInteractive(e.OriginalSource as DependencyObject)) return;
        try { DragMove(); } catch { /* mouse released early */ }
    }

    void OnLocationChanged(object? sender, EventArgs e)
    {
        _saveTimer ??= new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
        _saveTimer.Tick -= SavePos;
        _saveTimer.Tick += SavePos;
        _saveTimer.Stop();
        _saveTimer.Start();
    }

    void SavePos(object? s, EventArgs e)
    {
        _saveTimer?.Stop();
        Inst.X = Left; Inst.Y = Top;
        SettingsStore.SaveSoon();
    }

    void BuildMenu()
    {
        var menu = new ContextMenu();

        var styles = new MenuItem { Header = "Change style" };
        var list = Catalog.Styles(Inst.Type);
        for (int i = 0; i < list.Count; i++)
        {
            int idx = i;
            var mi = new MenuItem { Header = list[i].Name, IsChecked = i == Inst.Style };
            mi.Click += (_, _) => { Inst.Style = idx; SettingsStore.Save(); WidgetManager.Recreate(Inst); };
            styles.Items.Add(mi);
        }
        menu.Items.Add(styles);

        var scale = new MenuItem { Header = "Size" };
        foreach (var pct in new[] { 50, 75, 100, 125, 150, 200 })
        {
            var mi = new MenuItem { Header = pct + "%" };
            int p = pct;
            mi.Click += (_, _) => { Inst.Scale = p / 100.0; SettingsStore.Save(); Render(); };
            scale.Items.Add(mi);
        }
        menu.Items.Add(scale);

        var op = new MenuItem { Header = "Opacity" };
        foreach (var pct in new[] { 100, 85, 70, 50, 30 })
        {
            var mi = new MenuItem { Header = pct + "%" };
            int p = pct;
            mi.Click += (_, _) => { Inst.Opacity = p / 100.0; SettingsStore.Save(); Render(); };
            op.Items.Add(mi);
        }
        menu.Items.Add(op);

        var lockItem = new MenuItem { Header = Inst.Locked ? "Unlock position" : "Lock position" };
        lockItem.Click += (_, _) => { Inst.Locked = !Inst.Locked; SettingsStore.Save(); lockItem.Header = Inst.Locked ? "Unlock position" : "Lock position"; };
        menu.Items.Add(lockItem);

        menu.Items.Add(new MenuItem { Header = "Tip: hold Alt and drag to move", IsEnabled = false });
        menu.Items.Add(new Separator());

        var open = new MenuItem { Header = "Open WinMax settings" };
        open.Click += (_, _) => UI.MainWindow.ShowMain();
        menu.Items.Add(open);

        var remove = new MenuItem { Header = "Remove widget" };
        remove.Click += (_, _) => WidgetManager.Remove(Inst.Id);
        menu.Items.Add(remove);

        ContextMenu = menu;
    }
}
