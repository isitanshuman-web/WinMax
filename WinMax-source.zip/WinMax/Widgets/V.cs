using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using WinMax.Core;

namespace WinMax.Widgets;

/// <summary>One visual style of a widget. Build() returns the visual tree for the current moment.</summary>
public record StyleDef(string Name, bool Ticks, bool Card, Func<Ctx, UIElement> Build);

/// <summary>Everything a style needs to draw itself.</summary>
public class Ctx
{
    public DateTime Now { get; set; } = DateTime.Now;
    public WidgetInstance Inst { get; set; } = new();
    public bool Preview { get; set; }
    public Action? Refresh { get; set; }
    public AppSettings S => SettingsStore.S;
    public WeatherData? W => WeatherService.Current ?? (Preview ? WeatherData.Sample : null);

    public string Hm() => Now.ToString(S.Use24Hour ? "HH:mm" : "h:mm");
    public string HmAp() => Now.ToString(S.Use24Hour ? "HH:mm" : "h:mm tt");
    public string Temp(double c) => S.Fahrenheit ? $"{Math.Round(c * 9 / 5 + 32)}°F" : $"{Math.Round(c)}°C";
    public string TempShort(double c) => S.Fahrenheit ? $"{Math.Round(c * 9 / 5 + 32)}°" : $"{Math.Round(c)}°";
}

/// <summary>Small helpers so the style files stay short.</summary>
public static class V
{
    public static readonly FontFamily Light = new("Segoe UI Light");
    public static readonly FontFamily Reg = new("Segoe UI");
    public static readonly FontFamily Semi = new("Segoe UI Semibold");
    public static readonly FontFamily Mono = new("Consolas");
    public static readonly FontFamily Script = new("Segoe Script");
    public static readonly FontFamily Emoji = new("Segoe UI Emoji");
    public static readonly FontFamily Bahn = new("Bahnschrift");
    public static readonly FontFamily Serif = new("Georgia");

    public static TextBlock T(string text, double size, Brush fg, FontFamily? font = null, FontWeight? weight = null) => new()
    {
        Text = text, FontSize = size, Foreground = fg, FontFamily = font ?? Reg,
        FontWeight = weight ?? FontWeights.Normal, TextWrapping = TextWrapping.NoWrap
    };

    public static StackPanel VS(params UIElement[] kids)
    {
        var p = new StackPanel { Orientation = Orientation.Vertical };
        foreach (var k in kids) p.Children.Add(k);
        return p;
    }

    public static StackPanel HS(params UIElement[] kids)
    {
        var p = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var k in kids) p.Children.Add(k);
        return p;
    }

    public static Border Pad(UIElement c, double l, double t, double r, double b) => new() { Child = c, Padding = new Thickness(l, t, r, b) };
    public static Border Pad(UIElement c, double all) => Pad(c, all, all, all, all);

    public static T M<T>(this T e, double l, double t, double r, double b) where T : FrameworkElement { e.Margin = new Thickness(l, t, r, b); return e; }
    public static T Center<T>(this T e) where T : FrameworkElement { e.HorizontalAlignment = HorizontalAlignment.Center; return e; }
    public static T Right<T>(this T e) where T : FrameworkElement { e.HorizontalAlignment = HorizontalAlignment.Right; return e; }
    public static T Do<T>(this T e, Action<T> a) { a(e); return e; }

    public static string Spaced(string s) => string.Join("  ", s.Select(ch => ch.ToString()));

    public static T Shadow<T>(this T e) where T : UIElement
    {
        if (!Theme.IsLight)
            e.Effect = new DropShadowEffect { BlurRadius = 14, ShadowDepth = 1, Opacity = 0.6, Color = Colors.Black };
        return e;
    }

    public static T Glow<T>(this T e, Color c, double radius = 24) where T : UIElement
    {
        e.Effect = new DropShadowEffect { BlurRadius = radius, ShadowDepth = 0, Opacity = 1, Color = c };
        return e;
    }

    public static Point Pt(double cx, double cy, double r, double deg)
    {
        double a = deg * Math.PI / 180;
        return new Point(cx + r * Math.Sin(a), cy - r * Math.Cos(a));
    }

    public static Path Arc(double cx, double cy, double r, double startDeg, double sweepDeg, Brush stroke, double thickness)
    {
        sweepDeg = Math.Clamp(sweepDeg, 0.01, 359.9);
        var fig = new PathFigure { StartPoint = Pt(cx, cy, r, startDeg), IsClosed = false };
        fig.Segments.Add(new ArcSegment(Pt(cx, cy, r, startDeg + sweepDeg), new Size(r, r), 0, sweepDeg > 180, SweepDirection.Clockwise, true));
        var geo = new PathGeometry();
        geo.Figures.Add(fig);
        return new Path { Data = geo, Stroke = stroke, StrokeThickness = thickness, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round };
    }

    public static Ellipse Dot(double size, Brush fill) => new() { Width = size, Height = size, Fill = fill };

    public static Border Chip(UIElement child, Brush bg, double radius = 12, double padH = 12, double padV = 5) =>
        new() { Child = child, Background = bg, CornerRadius = new CornerRadius(radius), Padding = new Thickness(padH, padV, padH, padV) };

    public static Rectangle Line(double w, double h, Brush b) => new() { Width = w, Height = h, Fill = b };

    public static Brush A(Brush b, double opacity)
    {
        var c = b.CloneCurrentValue();
        c.Opacity = opacity;
        return c;
    }

    public static Border Check(bool done, Action toggle)
    {
        var box = new Border
        {
            Width = 18, Height = 18, CornerRadius = new CornerRadius(9), BorderThickness = new Thickness(1.5),
            BorderBrush = done ? Theme.Accent : Theme.Sub, Background = done ? Theme.Accent : Brushes.Transparent,
            Cursor = System.Windows.Input.Cursors.Hand,
            Child = done ? new TextBlock { Text = "✓", FontSize = 11, Foreground = Brushes.White, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, FontWeight = FontWeights.Bold } : null
        };
        box.MouseLeftButtonUp += (_, e) => { toggle(); e.Handled = true; };
        return box;
    }

    public static string DueText(DateTime? due, bool h24)
    {
        if (!due.HasValue) return "";
        var d = due.Value;
        string time = d.ToString(h24 ? "HH:mm" : "h:mm tt");
        if (d.Date == DateTime.Today) return time;
        if (d.Date == DateTime.Today.AddDays(1)) return "Tomorrow " + time;
        return d.ToString("ddd d MMM") + " " + time;
    }
}
