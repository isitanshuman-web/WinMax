using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using WinMax.Core;

namespace WinMax.Widgets;

public static class ClockStyles
{
    static readonly string[] HourWords = { "twelve", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven" };
    static readonly string[] MinPrefix = { "", "five past", "ten past", "quarter past", "twenty past", "twenty-five past", "half past", "twenty-five to", "twenty to", "quarter to", "ten to", "five to" };

    static string WordTime(DateTime n)
    {
        int m5 = (int)(Math.Round(n.Minute / 5.0) * 5);
        var d = n;
        if (m5 == 60) { d = n.AddHours(1); m5 = 0; }
        int idx = m5 / 5;
        int hour = idx > 6 ? d.Hour + 1 : d.Hour;
        string h = HourWords[hour % 12];
        return idx == 0 ? $"It's {h} o'clock" : $"It's {MinPrefix[idx]} {h}";
    }

    static UIElement Analog(Ctx c, double size, bool face, bool numerals, bool ticks, bool dots, bool seconds,
                            double hourT, double minT, bool accentMin, bool ring)
    {
        var cv = new Canvas { Width = size, Height = size };
        double r = size / 2, cx = r, cy = r;

        if (face)
        {
            var e = new Ellipse { Width = size - 4, Height = size - 4, Fill = Theme.CardBrush, Stroke = Theme.Stroke, StrokeThickness = 1.5 };
            Canvas.SetLeft(e, 2); Canvas.SetTop(e, 2);
            cv.Children.Add(e);
        }
        if (ring)
        {
            cv.Children.Add(V.Arc(cx, cy, r - 10, 0, 359.9, Theme.Stroke, 5));
            cv.Children.Add(V.Arc(cx, cy, r - 10, 0, Math.Max(0.5, c.Now.Second * 6.0), Theme.Accent, 5));
        }
        if (ticks)
        {
            for (int i = 0; i < 60; i++)
            {
                bool major = i % 5 == 0;
                var p1 = V.Pt(cx, cy, r - 8, i * 6);
                var p2 = V.Pt(cx, cy, major ? r - 20 : r - 14, i * 6);
                cv.Children.Add(new Line { X1 = p1.X, Y1 = p1.Y, X2 = p2.X, Y2 = p2.Y, Stroke = major ? Theme.Text : Theme.Sub, StrokeThickness = major ? 2 : 1 });
            }
        }
        if (dots)
        {
            for (int i = 0; i < 12; i++)
            {
                bool q = i % 3 == 0;
                var p = V.Pt(cx, cy, r - 14, i * 30);
                double s = q ? 8 : 4;
                var d = V.Dot(s, q ? Theme.Text : Theme.Sub);
                Canvas.SetLeft(d, p.X - s / 2); Canvas.SetTop(d, p.Y - s / 2);
                cv.Children.Add(d);
            }
        }
        if (numerals)
        {
            for (int i = 1; i <= 12; i++)
            {
                var p = V.Pt(cx, cy, r - 32, i * 30);
                var t = V.T(i.ToString(), 14, Theme.Text, V.Semi);
                t.Width = 26; t.TextAlignment = TextAlignment.Center;
                Canvas.SetLeft(t, p.X - 13); Canvas.SetTop(t, p.Y - 10);
                cv.Children.Add(t);
            }
        }

        void Hand(double deg, double len, double th, Brush b, double tail = 0)
        {
            double a = deg * Math.PI / 180;
            cv.Children.Add(new Line
            {
                X1 = cx - tail * Math.Sin(a), Y1 = cy + tail * Math.Cos(a),
                X2 = cx + len * Math.Sin(a), Y2 = cy - len * Math.Cos(a),
                Stroke = b, StrokeThickness = th, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round
            });
        }

        Hand((c.Now.Hour % 12 + c.Now.Minute / 60.0) * 30, r * 0.5, hourT, Theme.Text);
        Hand((c.Now.Minute + c.Now.Second / 60.0) * 6, r * 0.75, minT, accentMin ? Theme.Accent : Theme.Text);
        if (seconds) Hand(c.Now.Second * 6, r * 0.82, 1.6, Theme.Accent, 14);
        var hub = V.Dot(10, Theme.Accent);
        Canvas.SetLeft(hub, cx - 5); Canvas.SetTop(hub, cy - 5);
        cv.Children.Add(hub);
        return V.Pad(cv, 6);
    }

    static Border FlipDigits(string s)
    {
        var grid = new Grid();
        grid.Children.Add(V.T(s, 70, Brushes.White, V.Bahn, FontWeights.SemiBold).Center());
        grid.Children.Add(new Rectangle { Height = 2, Fill = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0)), VerticalAlignment = VerticalAlignment.Center });
        return new Border
        {
            Background = new SolidColorBrush(Color.FromRgb(0x23, 0x21, 0x2E)), CornerRadius = new CornerRadius(12),
            Padding = new Thickness(14, 2, 14, 2), Child = grid, BorderBrush = Theme.Stroke, BorderThickness = new Thickness(1)
        };
    }

    public static readonly List<StyleDef> All = new()
    {
        // 1
        new("Digital Classic", true, true, c =>
        {
            var time = V.T(c.Hm(), 58, Theme.Text, V.Light);
            var sec = V.T(c.Now.ToString("ss"), 20, Theme.Sub, V.Light).M(2, 10, 0, 0);
            sec.VerticalAlignment = VerticalAlignment.Top;
            var date = V.T(c.Now.ToString("dddd, MMMM d"), 15, Theme.Text).Center();
            return V.Pad(V.VS(V.HS(time, sec), date), 22, 10, 22, 14);
        }),
        // 2
        new("Big Thin", false, false, c => V.T(c.Hm(), 100, Theme.Text, V.Light).Shadow()),
        // 3
        new("Accent AM/PM", false, false, c => V.T(c.HmAp(), 42, Theme.Accent, V.Semi).Shadow()),
        // 4
        new("Stacked", false, true, c => V.Pad(V.VS(
            V.T(c.Now.ToString(c.S.Use24Hour ? "HH" : "hh"), 70, Theme.Text, V.Light).Center(),
            V.T(c.Now.ToString("mm"), 70, Theme.Accent, V.Light).Center().M(0, -18, 0, 0)), 24, 6, 24, 6)),
        // 5
        new("Seconds Ring", true, true, c =>
        {
            const double size = 190, r = size / 2;
            var cv = new Canvas { Width = size, Height = size };
            cv.Children.Add(V.Arc(r, r, r - 10, 0, 359.9, Theme.Stroke, 6));
            cv.Children.Add(V.Arc(r, r, r - 10, 0, Math.Max(0.5, c.Now.Second * 6.0), Theme.Accent, 6));
            var inner = V.VS(V.T(c.Hm(), 40, Theme.Text, V.Light).Center(), V.T(c.Now.ToString("ddd, MMM d"), 13, Theme.Sub).Center());
            var host = new Grid { Width = size, Height = size };
            host.Children.Add(cv);
            inner.VerticalAlignment = VerticalAlignment.Center; inner.HorizontalAlignment = HorizontalAlignment.Center;
            host.Children.Add(inner);
            return V.Pad(host, 10);
        }),
        // 6
        new("Analog Classic", true, false, c => Analog(c, 200, true, true, true, false, true, 5, 3.5, false, false)),
        // 7
        new("Analog Minimal", true, false, c => Analog(c, 190, false, false, false, true, false, 4, 3, false, false)),
        // 8
        new("Analog Modern", true, false, c => Analog(c, 200, true, false, false, false, false, 7, 5, true, true)),
        // 9
        new("Flip Cards", false, false, c =>
        {
            var row = V.HS(FlipDigits(c.Now.ToString(c.S.Use24Hour ? "HH" : "hh")), FlipDigits(c.Now.ToString("mm")).M(10, 0, 0, 0));
            if (c.S.Use24Hour) return row;
            return V.VS(row, V.T(c.Now.ToString("tt"), 16, Theme.Text, V.Semi).Right().M(0, 6, 4, 0).Shadow());
        }),
        // 10
        new("Neon Glow", false, false, c => V.T(c.HmAp(), 64, Theme.Accent, V.Bahn, FontWeights.Light).Glow(Theme.AccentC, 28)),
        // 11
        new("Retro Segments", false, true, c =>
        {
            var g = new Grid();
            g.Children.Add(V.T("88:88", 68, V.A(Theme.Text, 0.07), V.Mono, FontWeights.Bold));
            g.Children.Add(V.T(c.Now.ToString("HH:mm"), 68, Theme.Accent, V.Mono, FontWeights.Bold).Glow(Theme.AccentC, 10));
            return V.Pad(g, 22, 10, 22, 10);
        }),
        // 12
        new("Word Clock", false, true, c =>
        {
            var t = V.T(WordTime(c.Now), 28, Theme.Text, V.Light);
            t.TextWrapping = TextWrapping.Wrap; t.MaxWidth = 240;
            return V.Pad(t, 22, 16, 22, 16);
        }),
        // 13
        new("Compact Pill", false, false, c =>
        {
            var inner = V.HS(V.T("🕒", 18, Theme.Text, V.Emoji).M(0, 0, 8, 0), V.T(c.HmAp(), 22, Theme.Text, V.Semi));
            return new Border { Child = inner, Background = Theme.CardBrush, BorderBrush = Theme.Stroke, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(26), Padding = new Thickness(18, 8, 20, 8) };
        }),
        // 14
        new("Dual Zone", false, true, c =>
        {
            string fmt = c.S.Use24Hour ? "HH:mm" : "h:mm tt";
            var local = V.VS(V.T("LOCAL", 11, Theme.Sub, V.Semi), V.T(c.Now.ToString(fmt), 32, Theme.Text, V.Light));
            var utc = V.VS(V.T("UTC", 11, Theme.Sub, V.Semi), V.T(DateTime.UtcNow.ToString(fmt), 32, Theme.Accent, V.Light));
            return V.Pad(V.HS(local, V.Line(1, 52, Theme.Stroke).M(18, 0, 18, 0), utc), 22, 12, 22, 12);
        }),
        // 15
        new("Binary Dots", false, true, c =>
        {
            string digits = c.Now.ToString("HHmm");
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            for (int i = 0; i < 4; i++)
            {
                int v = digits[i] - '0';
                var col = new StackPanel { Margin = new Thickness(i == 2 ? 18 : 5, 0, 5, 0) };
                foreach (int bit in new[] { 8, 4, 2, 1 })
                    col.Children.Add(V.Dot(16, (v & bit) != 0 ? Theme.Accent : Theme.Stroke).M(0, 3, 0, 3));
                row.Children.Add(col);
            }
            return V.Pad(V.VS(row, V.T(c.Hm(), 13, Theme.Sub).Center().M(0, 8, 0, 0)), 20, 14, 20, 12);
        }),
    };
}
