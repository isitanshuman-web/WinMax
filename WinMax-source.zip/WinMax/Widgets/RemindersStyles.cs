using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using WinMax.Core;

namespace WinMax.Widgets;

public static class RemindersStyles
{
    static readonly Regex AtTime = new(@"\s*@\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\s*$", RegexOptions.IgnoreCase);

    /// <summary>Adds a reminder. "Call mom @5:30pm" sets a due time (today, or tomorrow if already past).</summary>
    public static void QuickAdd(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;
        DateTime? due = null;
        var m = AtTime.Match(text);
        if (m.Success)
        {
            int h = int.Parse(m.Groups[1].Value);
            int min = m.Groups[2].Success ? int.Parse(m.Groups[2].Value) : 0;
            string ap = m.Groups[3].Value.ToLower();
            if (ap == "pm" && h < 12) h += 12;
            if (ap == "am" && h == 12) h = 0;
            if (h < 24 && min < 60)
            {
                var t = DateTime.Today.AddHours(h).AddMinutes(min);
                if (t < DateTime.Now) t = t.AddDays(1);
                due = t;
                text = text.Substring(0, m.Index);
            }
        }
        ReminderStore.Add(text, due);
    }

    static List<ReminderItem> Items(int max) => ReminderStore.Active().Take(max).ToList();

    static UIElement AddBox(Ctx c, double width)
    {
        var tb = new TextBox
        {
            Width = width, Padding = new Thickness(10, 6, 10, 6), BorderThickness = new Thickness(0),
            Background = V.A(Theme.Text, 0.09), Foreground = Theme.Text, CaretBrush = Theme.Text, FontSize = 13, IsReadOnly = c.Preview,
            VerticalContentAlignment = VerticalAlignment.Center
        };
        var hint = V.T("Add a reminder…  (e.g. Call mom @5:30pm)", 12, Theme.Sub);
        hint.IsHitTestVisible = false; hint.Margin = new Thickness(11, 0, 0, 0); hint.VerticalAlignment = VerticalAlignment.Center; hint.TextTrimming = TextTrimming.CharacterEllipsis; hint.MaxWidth = width - 20;
        tb.TextChanged += (_, _) => hint.Visibility = tb.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
        tb.KeyDown += (_, e) =>
        {
            if (e.Key != Key.Enter || c.Preview) return;
            QuickAdd(tb.Text);
            tb.Text = "";
        };
        var g = new Grid { Margin = new Thickness(0, 8, 0, 0) };
        g.Children.Add(new Border { CornerRadius = new CornerRadius(10), ClipToBounds = true, Child = tb });
        g.Children.Add(hint);
        return g;
    }

    static UIElement Empty(string text = "All done 🎉") => V.T(text, 13, Theme.Sub).M(0, 6, 0, 6);

    static UIElement CheckRow(Ctx c, ReminderItem r, double width, double size = 14, bool time = true, Brush? fg = null)
    {
        var g = new Grid { Width = width, Margin = new Thickness(0, 4, 0, 4) };
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        g.ColumnDefinitions.Add(new ColumnDefinition());
        var chk = V.Check(r.Done, () => { if (!c.Preview) ReminderStore.Toggle(r.Id); });
        var text = V.VS(V.T(r.Text, size, fg ?? Theme.Text));
        ((TextBlock)text.Children[0]).TextTrimming = TextTrimming.CharacterEllipsis;
        if (time && r.Due.HasValue) text.Children.Add(V.T(V.DueText(r.Due, c.S.Use24Hour), 11, r.Due < DateTime.Now ? Brushes.IndianRed : Theme.Sub));
        text.Margin = new Thickness(10, 0, 0, 0);
        Grid.SetColumn(text, 1);
        g.Children.Add(chk); g.Children.Add(text);
        return g;
    }

    static StyleDef R(string name, bool card, Func<Ctx, UIElement> build) => new(name, false, card, build);

    public static readonly List<StyleDef> All = new()
    {
        // 1 Card with count (matches the reference image)
        R("Card with Count", true, c =>
        {
            var items = Items(3);
            int total = ReminderStore.ActiveCount;
            var icon = new Border { Width = 26, Height = 26, CornerRadius = new CornerRadius(13), Background = Theme.Accent, Child = V.T("☰", 13, Brushes.White).Center() };
            ((TextBlock)icon.Child).VerticalAlignment = VerticalAlignment.Center;
            var head = new Grid { Width = 170 };
            head.Children.Add(icon.Do(i => i.HorizontalAlignment = HorizontalAlignment.Left));
            head.Children.Add(V.T(total.ToString(), 26, Theme.Text, V.Light).Right());
            var sp = new StackPanel { Width = 170 };
            sp.Children.Add(head);
            sp.Children.Add(V.T("Reminders", 15, Theme.Accent, V.Semi).M(0, 6, 0, 4));
            foreach (var r in items) sp.Children.Add(new Border { BorderBrush = Theme.Stroke, BorderThickness = new Thickness(0, 1, 0, 0), Padding = new Thickness(0, 5, 0, 5), Child = V.T(r.Text, 13, Theme.Text).Do(t => t.TextTrimming = TextTrimming.CharacterEllipsis) });
            if (items.Count == 0) sp.Children.Add(Empty());
            if (total > items.Count) sp.Children.Add(V.T($"+ {total - items.Count} more", 12, Theme.Accent));
            return V.Pad(sp, 14);
        }),
        // 2
        R("Count Badge", true, c => V.Pad(V.VS(
            V.T(ReminderStore.ActiveCount.ToString(), 60, Theme.Accent, V.Light).Center(),
            V.T(ReminderStore.ActiveCount == 1 ? "reminder" : "reminders", 13, Theme.Sub).Center()), 30, 10, 30, 14)),
        // 3
        R("Checklist", true, c =>
        {
            var sp = new StackPanel { Width = 250 };
            sp.Children.Add(V.T("REMINDERS", 11, Theme.Sub, V.Semi).M(0, 0, 0, 4));
            var items = Items(6);
            foreach (var r in items) sp.Children.Add(CheckRow(c, r, 250));
            if (items.Count == 0) sp.Children.Add(Empty());
            sp.Children.Add(AddBox(c, 250));
            return V.Pad(sp, 16);
        }),
        // 4
        R("Minimal List", false, c =>
        {
            var sp = new StackPanel();
            foreach (var r in Items(5)) sp.Children.Add(V.T("•  " + r.Text, 16, Theme.Text, V.Light).M(0, 2, 0, 2));
            if (sp.Children.Count == 0) sp.Children.Add(V.T("Nothing to do", 16, Theme.Sub, V.Light));
            return sp.Shadow();
        }),
        // 5
        R("Timeline", true, c =>
        {
            var sp = new StackPanel { Width = 230 };
            var items = Items(5);
            for (int i = 0; i < items.Count; i++)
            {
                var r = items[i];
                var g = new Grid { Margin = new Thickness(0, 0, 0, 0) };
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(64) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(22) });
                g.ColumnDefinitions.Add(new ColumnDefinition());
                var time = V.T(r.Due.HasValue ? r.Due.Value.ToString(c.S.Use24Hour ? "HH:mm" : "h:mm tt") : "Anytime", 11, Theme.Sub).Do(t => t.VerticalAlignment = VerticalAlignment.Center);
                var rail = new Grid();
                rail.Children.Add(V.Line(2, 38, Theme.Stroke).Do(l => l.HorizontalAlignment = HorizontalAlignment.Center));
                rail.Children.Add(V.Dot(10, Theme.Accent).Do(d => { d.HorizontalAlignment = HorizontalAlignment.Center; d.VerticalAlignment = VerticalAlignment.Center; }));
                Grid.SetColumn(rail, 1);
                var text = V.T(r.Text, 13, Theme.Text).Do(t => { t.VerticalAlignment = VerticalAlignment.Center; t.TextTrimming = TextTrimming.CharacterEllipsis; });
                Grid.SetColumn(text, 2);
                g.Children.Add(time); g.Children.Add(rail); g.Children.Add(text);
                sp.Children.Add(g);
            }
            if (items.Count == 0) sp.Children.Add(Empty());
            return V.Pad(sp, 16);
        }),
        // 6
        R("Cards", false, c =>
        {
            var sp = new StackPanel { Width = 240 };
            var items = Items(4);
            foreach (var r in items)
                sp.Children.Add(new Border
                {
                    Background = Theme.CardBrush, BorderBrush = Theme.Stroke, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(12),
                    Padding = new Thickness(12, 8, 12, 8), Margin = new Thickness(0, 0, 0, 6), Child = CheckRow(c, r, 214)
                });
            if (items.Count == 0) sp.Children.Add(new Border { Background = Theme.CardBrush, CornerRadius = new CornerRadius(12), Padding = new Thickness(14), Child = Empty() });
            sp.Children.Add(AddBox(c, 240));
            return sp;
        }),
        // 7
        R("Today / Upcoming", true, c =>
        {
            var sp = new StackPanel { Width = 240 };
            var today = ReminderStore.Active().Where(r => !r.Due.HasValue || r.Due.Value.Date <= DateTime.Today).Take(4).ToList();
            var later = ReminderStore.Active().Where(r => r.Due.HasValue && r.Due.Value.Date > DateTime.Today).Take(3).ToList();
            sp.Children.Add(V.T("TODAY", 11, Theme.Accent, V.Semi));
            foreach (var r in today) sp.Children.Add(CheckRow(c, r, 240, 13));
            if (today.Count == 0) sp.Children.Add(Empty("Nothing for today"));
            sp.Children.Add(V.T("UPCOMING", 11, Theme.Accent, V.Semi).M(0, 8, 0, 0));
            foreach (var r in later) sp.Children.Add(CheckRow(c, r, 240, 13));
            if (later.Count == 0) sp.Children.Add(Empty("Nothing upcoming"));
            return V.Pad(sp, 16);
        }),
        // 8
        R("Next Up", true, c =>
        {
            var next = ReminderStore.Active().FirstOrDefault();
            if (next == null) return V.Pad(V.VS(V.T("NEXT UP", 11, Theme.Sub, V.Semi), V.T("All clear 🎉", 22, Theme.Text, V.Light)), 20, 14, 26, 14);
            var sp = V.VS(V.T("NEXT UP", 11, Theme.Accent, V.Semi),
                          V.T(next.Text, 22, Theme.Text, V.Light).Do(t => { t.TextWrapping = TextWrapping.Wrap; t.MaxWidth = 240; }).M(0, 2, 0, 2),
                          V.T(next.Due.HasValue ? V.DueText(next.Due, c.S.Use24Hour) : "No time set", 12, Theme.Sub));
            return V.Pad(sp, 20, 14, 26, 14);
        }),
        // 9
        R("Compact Strip", false, c =>
        {
            var next = ReminderStore.Active().FirstOrDefault();
            string label = next == null ? "No reminders" : "Next: " + next.Text + (next.Due.HasValue ? "  ·  " + V.DueText(next.Due, c.S.Use24Hour) : "");
            return new Border
            {
                Background = Theme.CardBrush, BorderBrush = Theme.Stroke, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(22), Padding = new Thickness(16, 8, 18, 8),
                Child = V.HS(V.Dot(8, Theme.Accent).Do(d => d.VerticalAlignment = VerticalAlignment.Center).M(0, 0, 10, 0), V.T(label, 13, Theme.Text))
            };
        }),
        // 10
        R("Priority Dots", true, c =>
        {
            var sp = new StackPanel { Width = 230 };
            foreach (var r in Items(6))
            {
                Brush dot = r.Due.HasValue && r.Due < DateTime.Now ? Brushes.IndianRed
                          : r.Due.HasValue && r.Due.Value.Date == DateTime.Today ? Theme.Accent : V.A(Theme.Sub, 0.6);
                var row = V.HS(V.Dot(9, dot).Do(d => d.VerticalAlignment = VerticalAlignment.Center).M(0, 0, 10, 0),
                               V.T(r.Text, 14, Theme.Text).Do(t => { t.TextTrimming = TextTrimming.CharacterEllipsis; t.MaxWidth = 190; }));
                row.Margin = new Thickness(0, 5, 0, 5);
                row.MouseLeftButtonUp += (_, _) => { if (!c.Preview) ReminderStore.Toggle(r.Id); };
                row.Cursor = Cursors.Hand;
                sp.Children.Add(row);
            }
            if (sp.Children.Count == 0) sp.Children.Add(Empty());
            return V.Pad(sp, 16);
        }),
        // 11
        R("Numbered", true, c =>
        {
            var sp = new StackPanel { Width = 230 };
            int n = 1;
            foreach (var r in Items(6))
                sp.Children.Add(V.HS(V.T(n++ + ".", 15, Theme.Accent, V.Semi).Do(t => t.Width = 26), V.T(r.Text, 14, Theme.Text).Do(t => { t.TextTrimming = TextTrimming.CharacterEllipsis; t.MaxWidth = 190; })).M(0, 3, 0, 3));
            if (sp.Children.Count == 0) sp.Children.Add(Empty());
            return V.Pad(sp, 18, 14, 18, 14);
        }),
        // 12
        R("Progress Ring", true, c =>
        {
            int done = ReminderStore.DoneCount, left = ReminderStore.ActiveCount, total = Math.Max(1, done + left);
            const double size = 120, r = 50;
            var cv = new Canvas { Width = size, Height = size };
            cv.Children.Add(V.Arc(size / 2, size / 2, r, 0, 359.9, Theme.Stroke, 8));
            if (done > 0) cv.Children.Add(V.Arc(size / 2, size / 2, r, 0, 359.9 * done / total, Theme.Accent, 8));
            var host = new Grid { Width = size, Height = size };
            host.Children.Add(cv);
            host.Children.Add(V.VS(V.T(left.ToString(), 30, Theme.Text, V.Light).Center(), V.T("left", 11, Theme.Sub).Center()).Do(s => s.VerticalAlignment = VerticalAlignment.Center));
            return V.Pad(host, 14);
        }),
        // 13
        R("Sticky List", false, c =>
        {
            var sp = new StackPanel { Width = 230 };
            sp.Children.Add(V.T("To do", 15, new SolidColorBrush(Color.FromRgb(0x4A, 0x3B, 0x00)), V.Semi).M(0, 0, 0, 4));
            var items = Items(5);
            foreach (var r in items)
            {
                sp.Children.Add(CheckRow(c, r, 206, 14, false, new SolidColorBrush(Color.FromRgb(0x33, 0x2A, 0x00))));
            }
            if (items.Count == 0) sp.Children.Add(V.T("Nothing to do ✓", 13, new SolidColorBrush(Color.FromRgb(0x6B, 0x5A, 0x1A))));
            return new Border { Background = new SolidColorBrush(Color.FromRgb(0xFF, 0xE9, 0x7A)), CornerRadius = new CornerRadius(4), Padding = new Thickness(12, 10, 12, 12), Child = sp };
        }),
        // 14
        R("Bare Checklist", false, c =>
        {
            var sp = new StackPanel();
            var items = Items(6);
            foreach (var r in items) sp.Children.Add(CheckRow(c, r, 240, 16, true));
            if (items.Count == 0) sp.Children.Add(V.T("Nothing to do ✓", 16, Theme.Sub, V.Light));
            return sp.Shadow();
        }),
        // 15
        R("Chips", true, c =>
        {
            var wrap = new WrapPanel { Width = 260 };
            foreach (var r in Items(8))
            {
                var chip = V.Chip(V.T(r.Text, 12, Theme.Text), V.A(Theme.Accent, 0.28), 14, 12, 5).Do(b => b.Margin = new Thickness(0, 0, 6, 6));
                chip.Cursor = Cursors.Hand;
                chip.MouseLeftButtonUp += (_, _) => { if (!c.Preview) ReminderStore.Toggle(r.Id); };
                wrap.Children.Add(chip);
            }
            if (wrap.Children.Count == 0) wrap.Children.Add(Empty());
            return V.Pad(V.VS(V.T("REMINDERS", 11, Theme.Sub, V.Semi).M(0, 0, 0, 6), wrap), 16, 12, 10, 8);
        }),
    };
}
