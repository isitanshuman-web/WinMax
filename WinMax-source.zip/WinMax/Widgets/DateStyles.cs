using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WinMax.Core;

namespace WinMax.Widgets;

public static class DateStyles
{
    static string Ordinal(int d)
    {
        if (d % 100 is >= 11 and <= 13) return d + "th";
        return d + (d % 10 switch { 1 => "st", 2 => "nd", 3 => "rd", _ => "th" });
    }

    public static readonly List<StyleDef> All = new()
    {
        // 1
        new("Spaced Weekday", false, false, c => V.T(V.Spaced(c.Now.ToString("dddd").ToUpper()), 40, Theme.Text, V.Bahn, FontWeights.Light).Shadow()),
        // 2
        new("Big Day + Month", false, false, c =>
        {
            var day = V.T(c.Now.ToString("dd"), 90, V.A(Theme.Text, 0.55), V.Bahn, FontWeights.SemiBold);
            var right = V.VS(V.T(c.Now.ToString("ddd . MMMM"), 26, Theme.Text, V.Light), V.T(c.Now.ToString("yyyy"), 14, Theme.Sub));
            right.VerticalAlignment = VerticalAlignment.Center; right.Margin = new Thickness(10, 0, 0, 0);
            return V.HS(day, right).Shadow();
        }),
        // 3
        new("Full Long", false, true, c => V.Pad(V.T(c.Now.ToString("dddd, MMMM d"), 24, Theme.Text, V.Light), 22, 12, 22, 12)),
        // 4
        new("Numeric", false, true, c => V.Pad(V.T(c.Now.ToString("dd / MM / yyyy"), 26, Theme.Text, V.Bahn, FontWeights.Light), 22, 10, 22, 10)),
        // 5
        new("ISO", false, true, c => V.Pad(V.T(c.Now.ToString("yyyy-MM-dd"), 24, Theme.Accent, V.Mono, FontWeights.SemiBold), 20, 10, 20, 10)),
        // 6
        new("Badge Square", false, false, c =>
        {
            var top = new Border { Background = Theme.Accent, CornerRadius = new CornerRadius(14, 14, 0, 0), Padding = new Thickness(0, 5, 0, 5), Child = V.T(c.Now.ToString("MMM").ToUpper(), 15, Brushes.White, V.Semi).Center() };
            var body = new Border { Background = Theme.CardBrush, CornerRadius = new CornerRadius(0, 0, 14, 14), Padding = new Thickness(0, 2, 0, 8), Child = V.T(c.Now.Day.ToString(), 52, Theme.Text, V.Semi).Center() };
            var sp = V.VS(top, body); sp.Width = 96;
            return sp;
        }),
        // 7
        new("Day Stack", false, true, c => V.Pad(V.VS(
            V.T(c.Now.ToString("dddd").ToUpper(), 13, Theme.Accent, V.Semi).Center(),
            V.T(c.Now.Day.ToString(), 64, Theme.Text, V.Light).Center().M(0, -6, 0, -6),
            V.T(c.Now.ToString("MMMM yyyy"), 14, Theme.Sub).Center()), 28, 12, 28, 14)),
        // 8
        new("Ordinal", false, true, c => V.Pad(V.HS(
            V.T(Ordinal(c.Now.Day), 34, Theme.Accent, V.Light),
            V.T(" " + c.Now.ToString("MMMM"), 34, Theme.Text, V.Light)), 22, 10, 22, 12)),
        // 9
        new("Year Progress", false, true, c =>
        {
            int doy = c.Now.DayOfYear, total = DateTime.IsLeapYear(c.Now.Year) ? 366 : 365;
            var track = new Grid { Width = 200, Height = 6, Margin = new Thickness(0, 8, 0, 0) };
            track.Children.Add(new Border { Background = Theme.Stroke, CornerRadius = new CornerRadius(3) });
            track.Children.Add(new Border { Background = Theme.Accent, CornerRadius = new CornerRadius(3), HorizontalAlignment = HorizontalAlignment.Left, Width = 200.0 * doy / total });
            return V.Pad(V.VS(V.T($"Day {doy} of {total}", 22, Theme.Text, V.Light), track, V.T($"{Math.Round(100.0 * doy / total)}% of {c.Now.Year}", 12, Theme.Sub).M(0, 6, 0, 0)), 22, 14, 22, 14);
        }),
        // 10
        new("Week Number", false, true, c => V.Pad(V.HS(
            V.T("WEEK ", 13, Theme.Sub, V.Semi).M(0, 0, 0, 6),
            V.T(ISOWeek.GetWeekOfYear(c.Now).ToString(), 44, Theme.Accent, V.Light),
            V.T(" · " + c.Now.Year, 16, Theme.Sub).M(0, 0, 0, 6)).Center(), 22, 8, 22, 8)),
        // 11
        new("Vertical Weekday", false, false, c =>
        {
            var vert = V.T(V.Spaced(c.Now.ToString("dddd").ToUpper()), 16, Theme.Sub, V.Semi);
            vert.LayoutTransform = new RotateTransform(-90);
            return V.HS(vert, V.T(c.Now.ToString("dd"), 84, Theme.Text, V.Bahn, FontWeights.Light).M(6, 0, 0, 0)).Shadow();
        }),
        // 12
        new("Minimal Month Day", false, false, c => V.T(c.Now.ToString("MMM d"), 44, Theme.Text, V.Light).Shadow()),
        // 13
        new("Calendar Page", false, false, c =>
        {
            var header = new Border { Background = new SolidColorBrush(Color.FromRgb(0xE5, 0x39, 0x35)), CornerRadius = new CornerRadius(10, 10, 0, 0), Padding = new Thickness(0, 4, 0, 4), Child = V.T(c.Now.ToString("MMMM yyyy"), 13, Brushes.White, V.Semi).Center() };
            var page = new Border { Background = new SolidColorBrush(Color.FromRgb(0xFA, 0xFA, 0xFA)), CornerRadius = new CornerRadius(0, 0, 10, 10), Padding = new Thickness(0, 0, 0, 6),
                Child = V.VS(V.T(c.Now.Day.ToString(), 56, new SolidColorBrush(Color.FromRgb(0x22, 0x22, 0x22)), V.Semi).Center(),
                             V.T(c.Now.ToString("dddd"), 14, new SolidColorBrush(Color.FromRgb(0x66, 0x66, 0x66))).Center().M(0, -6, 0, 0)) };
            var sp = V.VS(header, page); sp.Width = 130;
            return sp;
        }),
        // 14
        new("Accent Capsule", false, false, c => new Border
        {
            Background = Theme.Accent, CornerRadius = new CornerRadius(22), Padding = new Thickness(22, 8, 22, 9),
            Child = V.T(c.Now.ToString("ddd · d MMM"), 20, Brushes.White, V.Semi)
        }),
        // 15
        new("Full Wide", false, false, c => V.T(c.Now.ToString("dddd, d MMMM yyyy"), 30, Theme.Text, V.Light).Shadow()),
    };
}
