using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WinMax.Core;

namespace WinMax.Widgets;

public static class WeatherStyles
{
    static UIElement NoLocation(bool bare) => V.Pad(V.VS(
        V.T("⛅", 28, Theme.Text, V.Emoji).Center(),
        V.T("Set your location", 14, Theme.Text, V.Semi).Center(),
        V.T("Open WinMax → Location", 11, Theme.Sub).Center()), 20, 14, 20, 14);

    static StyleDef S(string name, bool card, Func<Ctx, WeatherData, UIElement> build, bool bare = false) =>
        new(name, false, card, c => c.W == null ? NoLocation(bare) : build(c, c.W));

    static UIElement Stat(string icon, string label, string value) => V.Pad(V.VS(
        V.T(icon, 20, Theme.Text, V.Emoji).Center(),
        V.T(value, 18, Theme.Text, V.Semi).Center(),
        V.T(label, 11, Theme.Sub).Center()), 14, 10, 14, 10);

    static UIElement DayCol(Ctx c, DayForecast d, bool first) => new Border
    {
        Width = 58, Padding = new Thickness(0, 8, 0, 8), Margin = new Thickness(2), CornerRadius = new CornerRadius(12),
        Background = first ? V.A(Theme.Accent, 0.28) : Brushes.Transparent,
        Child = V.VS(
            V.T(first ? "Today" : d.Date.ToString("ddd"), 12, Theme.Sub, V.Semi).Center(),
            V.T(WeatherData.Icon(d.Code), 22, Theme.Text, V.Emoji).Center().M(0, 4, 0, 4),
            V.T(c.TempShort(d.Max), 14, Theme.Text, V.Semi).Center(),
            V.T(c.TempShort(d.Min), 12, Theme.Sub).Center())
    };

    public static readonly List<StyleDef> All = new()
    {
        // 1
        S("Compact", true, (c, w) => V.Pad(V.HS(
            V.T(WeatherData.Icon(w.Code, w.IsDay), 34, Theme.Text, V.Emoji).M(0, 0, 10, 0),
            V.VS(V.T(c.Temp(w.Temp), 26, Theme.Text, V.Light), V.T(w.City, 12, Theme.Sub))), 18, 10, 22, 10)),
        // 2
        S("Big Temp", true, (c, w) => V.Pad(V.VS(
            V.T(c.Temp(w.Temp), 72, Theme.Text, V.Light).Center(),
            V.T(WeatherData.Describe(w.Code), 16, Theme.Accent, V.Semi).Center(),
            V.T(w.City, 12, Theme.Sub).Center().M(0, 2, 0, 0)), 30, 10, 30, 14)),
        // 3
        S("Sentence", false, (c, w) => V.VS(
            V.T($"It is {c.Temp(w.Temp)}, {WeatherData.Describe(w.Code)}", 20, Theme.Text, V.Light),
            V.T($"Expected: {c.Temp(w.Days[0].Min)} – {c.Temp(w.Days[0].Max)} today", 12, Theme.Sub)).Shadow(), true),
        // 4
        S("Corner Badge", false, (c, w) => V.HS(
            V.T(WeatherData.Icon(w.Code, w.IsDay), 18, Theme.Text, V.Emoji).M(0, 0, 8, 0),
            V.VS(V.T(c.Temp(w.Temp), 13, Theme.Text, V.Semi), V.T(WeatherData.Describe(w.Code), 11, Theme.Sub))).Shadow(), true),
        // 5
        S("Detail Card", true, (c, w) => V.Pad(V.VS(
            V.HS(V.T(WeatherData.Icon(w.Code, w.IsDay), 38, Theme.Text, V.Emoji).M(0, 0, 12, 0),
                 V.VS(V.T(c.Temp(w.Temp), 32, Theme.Text, V.Light), V.T(WeatherData.Describe(w.Code), 13, Theme.Sub))),
            V.Line(210, 1, Theme.Stroke).M(0, 10, 0, 8),
            V.T($"Feels like {c.Temp(w.Feels)}", 12, Theme.Text),
            V.T($"Humidity {w.Humidity}%  ·  Wind {Math.Round(w.Wind)} km/h", 12, Theme.Sub).M(0, 3, 0, 0)), 18, 14, 18, 14)),
        // 6
        S("5-Day Row", true, (c, w) =>
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            for (int i = 0; i < w.Days.Count; i++) row.Children.Add(DayCol(c, w.Days[i], i == 0));
            return V.Pad(row, 8);
        }),
        // 7
        S("5-Day List", true, (c, w) =>
        {
            var sp = new StackPanel { Width = 220 };
            sp.Children.Add(V.T(w.City, 13, Theme.Sub, V.Semi).M(0, 0, 0, 6));
            for (int i = 0; i < w.Days.Count; i++)
            {
                var d = w.Days[i];
                var g = new Grid();
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(34) });
                g.ColumnDefinitions.Add(new ColumnDefinition());
                var a = V.T(i == 0 ? "Today" : d.Date.ToString("ddd"), 13, Theme.Text);
                var b = V.T(WeatherData.Icon(d.Code), 16, Theme.Text, V.Emoji); Grid.SetColumn(b, 1);
                var t = V.T($"{c.TempShort(d.Max)}  {c.TempShort(d.Min)}", 13, Theme.Sub).Right(); Grid.SetColumn(t, 2);
                g.Children.Add(a); g.Children.Add(b); g.Children.Add(t);
                g.Margin = new Thickness(0, 4, 0, 4);
                sp.Children.Add(g);
            }
            return V.Pad(sp, 18, 14, 18, 12);
        }),
        // 8
        S("Hero", true, (c, w) => V.Pad(V.VS(
            V.T(w.City, 14, Theme.Sub, V.Semi),
            V.HS(V.T(WeatherData.Icon(w.Code, w.IsDay), 56, Theme.Text, V.Emoji).M(0, 0, 14, 0),
                 V.VS(V.T(c.Temp(w.Temp), 44, Theme.Text, V.Light),
                      V.T($"H {c.TempShort(w.Days[0].Max)}  L {c.TempShort(w.Days[0].Min)}", 12, Theme.Sub)))), 22, 14, 26, 14)),
        // 9
        S("Pill", false, (c, w) => new Border
        {
            Background = Theme.CardBrush, BorderBrush = Theme.Stroke, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(24), Padding = new Thickness(16, 7, 18, 7),
            Child = V.HS(V.T(WeatherData.Icon(w.Code, w.IsDay), 18, Theme.Text, V.Emoji).M(0, 0, 8, 0), V.T(c.Temp(w.Temp), 18, Theme.Text, V.Semi))
        }),
        // 10
        S("Humidity & Wind", true, (c, w) => V.Pad(V.HS(Stat("💧", "Humidity", w.Humidity + "%"), V.Line(1, 60, Theme.Stroke), Stat("💨", "Wind", Math.Round(w.Wind) + " km/h")), 6)),
        // 11
        S("Sun Times", true, (c, w) => V.Pad(V.HS(
            Stat("🌅", "Sunrise", w.Sunrise.ToString(c.S.Use24Hour ? "HH:mm" : "h:mm tt")),
            V.Line(1, 60, Theme.Stroke),
            Stat("🌇", "Sunset", w.Sunset.ToString(c.S.Use24Hour ? "HH:mm" : "h:mm tt"))), 6)),
        // 12
        S("Feels Like", true, (c, w) => V.Pad(V.VS(
            V.T("FEELS LIKE", 11, Theme.Sub, V.Semi).Center(),
            V.T(c.Temp(w.Feels), 52, Theme.Accent, V.Light).Center(),
            V.T($"Actual {c.Temp(w.Temp)}", 12, Theme.Sub).Center()), 28, 12, 28, 14)),
        // 13
        S("Vertical Card", true, (c, w) => V.Pad(V.VS(
            V.T(WeatherData.Icon(w.Code, w.IsDay), 52, Theme.Text, V.Emoji).Center(),
            V.T(c.Temp(w.Temp), 34, Theme.Text, V.Light).Center(),
            V.T(WeatherData.Describe(w.Code), 13, Theme.Sub).Center(),
            V.T(w.City, 12, Theme.Accent, V.Semi).Center().M(0, 6, 0, 0)), 26, 16, 26, 16)),
        // 14
        S("Range Bar", true, (c, w) =>
        {
            var d = w.Days[0];
            double span = Math.Max(1, d.Max - d.Min);
            double pos = Math.Clamp((w.Temp - d.Min) / span, 0, 1);
            var track = new Grid { Width = 200, Height = 6, Margin = new Thickness(0, 8, 0, 6) };
            track.Children.Add(new Border { CornerRadius = new CornerRadius(3), Background = new LinearGradientBrush(Theme.Accent2C, Theme.AccentC, 0) });
            track.Children.Add(V.Dot(12, Brushes.White).Do(e => { e.HorizontalAlignment = HorizontalAlignment.Left; e.Margin = new Thickness(188 * pos, -3, 0, -3); }));
            var ends = new Grid { Width = 200 };
            ends.Children.Add(V.T(c.TempShort(d.Min), 12, Theme.Sub));
            ends.Children.Add(V.T(c.TempShort(d.Max), 12, Theme.Sub).Right());
            return V.Pad(V.VS(V.HS(V.T(c.Temp(w.Temp), 30, Theme.Text, V.Light), V.T("  " + WeatherData.Describe(w.Code), 13, Theme.Sub).M(0, 12, 0, 0)), track, ends), 18, 12, 18, 12);
        }),
        // 15
        S("Mini Forecast", true, (c, w) =>
        {
            var today = w.Days[0]; var next = w.Days.Count > 1 ? w.Days[1] : w.Days[0];
            UIElement Half(string label, DayForecast d, double? now) => V.Pad(V.VS(
                V.T(label, 11, Theme.Sub, V.Semi).Center(),
                V.T(WeatherData.Icon(d.Code), 26, Theme.Text, V.Emoji).Center().M(0, 2, 0, 2),
                V.T(now.HasValue ? c.Temp(now.Value) : c.Temp(d.Max), 20, Theme.Text, V.Light).Center(),
                V.T(WeatherData.Describe(d.Code), 11, Theme.Sub).Center()), 14, 10, 14, 10);
            return V.HS(Half("NOW", today, w.Temp), V.Line(1, 80, Theme.Stroke), Half("TOMORROW", next, null));
        }),
    };
}
