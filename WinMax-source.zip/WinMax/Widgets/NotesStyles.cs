using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WinMax.Core;

namespace WinMax.Widgets;

public static class NotesStyles
{
    record Spec(string Header, string HeaderBg, string HeaderFg, string Body, string Fg, FontFamily Font, double Size,
                double W = 230, double H = 190, bool Lined = false, double Radius = 6, string? Border = null, bool Tape = false);

    static SolidColorBrush Br(string hex) => Theme.Solid(hex);

    static UIElement Note(Ctx c, Spec s)
    {
        string id = c.Inst.Id;
        c.S.Notes.TryGetValue(id, out var saved);
        Brush fg = Br(s.Fg);

        Brush bodyBrush = Br(s.Body);
        if (s.Lined)
        {
            var g = new DrawingGroup();
            g.Children.Add(new GeometryDrawing(Br(s.Body), null, new RectangleGeometry(new Rect(0, 0, 10, 26))));
            g.Children.Add(new GeometryDrawing(new SolidColorBrush(Color.FromArgb(70, 60, 90, 160)), null, new RectangleGeometry(new Rect(0, 25, 10, 1))));
            bodyBrush = new DrawingBrush(g)
            {
                TileMode = TileMode.Tile, Viewport = new Rect(0, 0, 10, 26), ViewportUnits = BrushMappingMode.Absolute,
                Viewbox = new Rect(0, 0, 10, 26), ViewboxUnits = BrushMappingMode.Absolute
            };
        }

        var tb = new TextBox
        {
            Text = c.Preview && string.IsNullOrEmpty(saved) ? "Your note appears here.\nClick and start typing." : saved ?? "",
            AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, Background = s.Lined ? bodyBrush : Brushes.Transparent,
            BorderThickness = new Thickness(0), Foreground = fg, CaretBrush = fg, FontFamily = s.Font, FontSize = s.Size,
            Width = s.W, Height = s.H, Padding = new Thickness(12, s.Lined ? 0 : 10, 12, 10),
            VerticalScrollBarVisibility = ScrollBarVisibility.Hidden, IsReadOnly = c.Preview, SelectionBrush = Theme.Accent
        };
        if (s.Lined)
        {
            TextBlock.SetLineHeight(tb, 26);
            TextBlock.SetLineStackingStrategy(tb, LineStackingStrategy.BlockLineHeight);
        }
        if (!c.Preview)
            tb.TextChanged += (_, _) => { c.S.Notes[id] = tb.Text; SettingsStore.SaveSoon(); };

        var stack = new StackPanel();
        if (!string.IsNullOrEmpty(s.Header))
        {
            stack.Children.Add(new Border
            {
                Background = Br(s.HeaderBg), Padding = new Thickness(12, 6, 12, 6),
                Child = V.T(s.Header, 12, Br(s.HeaderFg), V.Semi)
            });
        }
        stack.Children.Add(tb);

        var outer = new Border
        {
            Background = s.Lined ? bodyBrush : bodyBrush, CornerRadius = new CornerRadius(s.Radius), Child = stack,
            ClipToBounds = true
        };
        if (s.Border != null) { outer.BorderBrush = Br(s.Border); outer.BorderThickness = new Thickness(1.5); }

        if (!s.Tape) return outer;
        var tape = new Border { Width = 70, Height = 20, Background = new SolidColorBrush(Color.FromArgb(150, 255, 235, 150)), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 0, 0, -10), RenderTransform = new RotateTransform(-3, 35, 10) };
        var grid = new Grid();
        grid.Children.Add(outer);
        grid.Margin = new Thickness(0, 10, 0, 0);
        var host = new Grid();
        host.Children.Add(grid);
        tape.VerticalAlignment = VerticalAlignment.Top;
        tape.Margin = new Thickness(0);
        host.Children.Add(tape);
        return host;
    }

    static StyleDef N(string name, Func<Ctx, Spec> spec) => new(name, false, false, c => Note(c, spec(c)));

    public static readonly List<StyleDef> All = new()
    {
        // 1 Sticky Yellow (header like the reference image)
        N("Sticky Yellow", _ => new Spec("Notes", "#FFD83B", "#3A2F00", "#2B2A30", "#F4F1E8", V.Reg, 13)),
        // 2
        N("Sticky Pink",   _ => new Spec("Notes", "#FF8FB1", "#4A0F25", "#FFE3EC", "#3A1B27", V.Reg, 13)),
        // 3
        N("Sticky Blue",   _ => new Spec("Notes", "#6EC6FF", "#06293D", "#E3F4FF", "#12303F", V.Reg, 13)),
        // 4
        N("Sticky Green",  _ => new Spec("Notes", "#7EE3A1", "#0B3A1F", "#E6FBEE", "#17352A", V.Reg, 13)),
        // 5 follows the theme accent
        N("Accent Header", c => new Spec("Notes", Theme.AccentC.ToString(), "#FFFFFF", Theme.IsLight ? "#FFFFFF" : "#1F1C29", Theme.IsLight ? "#1D1B26" : "#F3F0FA", V.Reg, 13, Radius: 12)),
        // 6
        N("Lined Paper",   _ => new Spec("", "", "", "#FFFDF4", "#2B2B3A", V.Reg, 14, Lined: true, Radius: 4, H: 208)),
        // 7
        N("Dark Minimal",  _ => new Spec("", "", "", "#CC141219", "#F3F0FA", V.Light, 15, Radius: 14)),
        // 8
        N("Outlined",      c => new Spec("", "", "", "#22000000", Theme.IsLight ? "#1D1B26" : "#FFFFFF", V.Reg, 14, Radius: 12, Border: Theme.AccentC.ToString())),
        // 9
        N("Terminal",      _ => new Spec("● ● ●  notes.txt", "#2A2D2A", "#7CFF9B", "#0D120E", "#7CFF9B", V.Mono, 13, Radius: 8)),
        // 10
        N("Handwriting",   _ => new Spec("", "", "", "#FFF9DA", "#33302A", V.Script, 15, Radius: 3, H: 200)),
        // 11
        N("Big Text",      _ => new Spec("", "", "", "#00000000", "#FFFFFF", V.Light, 26, W: 320, H: 150, Radius: 0)),
        // 12
        N("Taped Note",    _ => new Spec("", "", "", "#FFF7C2", "#3A3320", V.Script, 15, Radius: 2, Tape: true, H: 190)),
        // 13
        N("Serif Paper",   _ => new Spec("", "", "", "#FAF6EE", "#2C2A26", V.Serif, 14, Radius: 8, W: 250, H: 200)),
        // 14
        N("Slim Strip",    _ => new Spec("", "", "", "#B3141219", "#F3F0FA", V.Reg, 14, W: 340, H: 70, Radius: 35)),
        // 15
        N("Checklist Mono", _ => new Spec("TODO", "#3B3355", "#E8DEFF", "#1B1826", "#E8E4F5", V.Mono, 13, Radius: 10)),
    };
}
